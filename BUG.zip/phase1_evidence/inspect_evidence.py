from bs4 import BeautifulSoup
from pathlib import Path
import json
P=Path('phase1_evidence')
for n in ['company','business','factory','electric','movable']:
 s=BeautifulSoup((P/(n+'.html')).read_bytes(),'html.parser')
 print(n,s.select_one('main').get_text(' ',strip=True))
 print([(a.get_text(' ',strip=True),a['href']) for a in s.select('main .item > a')])
 print('pagination',[(a.text,a.get('href')) for a in s.select('.pagination a')])
for n in ['law1_all','law1','moj']:
 print(n,json.loads((P/(n+'.json')).read_text(encoding='utf-8')))
s=BeautifulSoup((P/'law3.html').read_bytes(),'html.parser');print('PRE PARENT',str(s.select_one('pre').parent)[:2000])
