exec(open('phase1_evidence/probe.py',encoding='utf-8-sig').read().split('for name,url in urls.items():')[0])
from urllib.parse import urljoin
urls={
'article2':'https://web.law.ntpc.gov.tw/Scripts/FLAWDOC01.aspx?fcode=C0040048&flno=2',
'company':'https://www.economic.ntpc.gov.tw/Api/Link/Index?id=2176',
'business':'https://www.economic.ntpc.gov.tw/Api/Link/Index?id=2300',
'factory':'https://www.economic.ntpc.gov.tw/Api/Link/Index?id=2298',
'electric':'https://www.economic.ntpc.gov.tw/Api/Link/Index?id=2301',
'movable':'https://www.economic.ntpc.gov.tw/Api/Link/Index?id=2299',
'moj':'http://law.moj.gov.tw/LawClass/LawAll.aspx?PCode=J0020019',
'robots_moj':'https://law.moj.gov.tw/robots.txt'}
exec(open('phase1_evidence/probe.py',encoding='utf-8-sig').read().split('for name,url in urls.items():')[1].join(['for name,url in urls.items():','']))
s=BeautifulSoup((P/'law1.html').read_bytes(),'html.parser')
data={i['name']:i.get('value','') for i in s.select('input[type=hidden][name]')}
b=s.select_one('#cph_content_B5'); data[b['name']]=b['value']
r=requests.post('https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040063',data=data,timeout=35)
(P/'law1_all.html').write_bytes(r.content)
(P/'law1_all.json').write_text(json.dumps({'url':r.url,'status':r.status_code,'headers':dict(r.headers),'redirects':[(x.status_code,x.url) for x in r.history]},ensure_ascii=False,indent=2),encoding='utf-8')
print('POST ALL',r.status_code,r.url,BeautifulSoup(r.content,'html.parser').get_text(' ',strip=True)[-1600:])
for n in ['law2','article2','company','business','factory','electric','movable','moj']:
 s=BeautifulSoup((P/(n+'.html')).read_bytes(),'html.parser'); print('\nDETAIL',n); print(s.get_text(' ',strip=True)[-3500:]); print([(a.get_text(' ',strip=True),a.get('href')) for a in s.select('a[href]') if any(k in a['href'].lower() for k in ['download','.doc','.pdf','.odt','.xls','.zip'])]);
 if n=='law2': print(s.select_one('div.content'))
