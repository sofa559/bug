from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import json
P=Path('phase1_evidence')
checks={
'law1':['.c-law table.tab-edit:first-of-type tr:first-child td .lawname','.c-law table.tab-edit:first-of-type tr:nth-of-type(2) td .lawname','#cph_content_B5'],
'law2':['.content .edit-title .lawname','.content .edit-title .col-th','.content .worddisaplay','.content .fileZone a[href]'],
'law3':['#cph_content_lawheader_hlkLNNAME','#cph_content_lawheader_law','.content2 td.col-td pre'],
'law1_all':['.content2 td.col-td pre'],
'law4':['.c-law a[href*="Download.ashx"]'],
'article2':['a[id^="cph_content_rptZFILES_"]']}
for n,selectors in checks.items():
 s=BeautifulSoup((P/(n+'.html')).read_bytes(),'html.parser')
 for sel in selectors: print(n,sel,len(s.select(sel)))
rows=[]
for n in ['list1','list2','list3','list4','company','business','factory','electric','movable']:
 s=BeautifulSoup((P/(n+'.html')).read_bytes(),'html.parser')
 for a in s.select('main#main .item > a'):
  rows.append({'source_sample':n,'title':a.get_text(' ',strip=True),'href':a['href'],'absolute_url':urljoin('https://www.economic.ntpc.gov.tw',a['href'])})
(P/'observed_links.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('observed entries',len(rows))
s=BeautifulSoup((P/'home.html').read_bytes(),'html.parser')
print('home entry',len(s.select('a[href="/List/about-law"]')))
