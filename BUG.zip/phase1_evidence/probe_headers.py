import requests,json,time
from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urljoin
P=Path('phase1_evidence')
s=BeautifulSoup((P/'list2.html').read_bytes(),'html.parser')
urls={
'economic_pdf':urljoin('https://www.economic.ntpc.gov.tw',s.select_one('main .item > a')['href']),
'news_pdf':'https://web.law.ntpc.gov.tw/DownloadNews.ashx?msgid=6706&fileid=10150',
'law_pdf':'https://web.law.ntpc.gov.tw/Download.ashx?pfid=0000259553'}
results=[]
for n,u in urls.items():
 with requests.get(u,stream=True,timeout=30) as r:
  chunk=next(r.iter_content(32),b'')
  d={'sample':n,'url':u,'final_url':r.url,'status':r.status_code,'headers':dict(r.headers),'first32_hex':chunk.hex(),'first32_repr':repr(chunk)}
  results.append(d);print(json.dumps(d,ensure_ascii=False))
 time.sleep(1)
(P/'attachment_headers.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
for n in [1,2,3,4]:
 s=BeautifulSoup((P/('list'+str(n)+'.html')).read_bytes(),'html.parser')
 print('list count',n,len(s.select('main#main .item > a')))
