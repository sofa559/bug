import requests,json,time
from pathlib import Path
from bs4 import BeautifulSoup
P=Path('phase1_evidence')
urls={
'home':'https://www.economic.ntpc.gov.tw/',
'robots_economic':'https://www.economic.ntpc.gov.tw/robots.txt',
'robots_law':'https://web.law.ntpc.gov.tw/robots.txt',
'list2':'https://www.economic.ntpc.gov.tw/List/about-law?page=2',
'list3':'https://www.economic.ntpc.gov.tw/List/about-law?page=3',
'list4':'https://www.economic.ntpc.gov.tw/List/about-law?page=4',
'law1':'https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040063',
'law2':'https://web.law.ntpc.gov.tw/news.aspx?msgid=6706',
'law3':'https://web.law.ntpc.gov.tw/Scripts/FLAWDAT0202.aspx?fcode=C0040048',
'law4':'https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040044'}
for name,url in urls.items():
 try:
  r=requests.get(url,timeout=35)
  meta={'url':url,'final_url':r.url,'status':r.status_code,'headers':dict(r.headers),'encoding':r.encoding,'apparent_encoding':r.apparent_encoding,'redirects':[(x.status_code,x.url) for x in r.history]}
  (P/(name+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
  (P/(name+'.html')).write_bytes(r.content)
  s=BeautifulSoup(r.content,'html.parser')
  print(name,r.status_code,r.url,r.headers.get('Content-Type'),r.encoding)
  if name.startswith('list'): print([(a.get_text(' ',strip=True),a.get('href')) for a in s.select('main#main .item > a')])
  elif name.startswith('law'): print(s.get_text(' ',strip=True)[-16000:])
  elif name.startswith('robots'): print(r.text[:3000])
 except Exception as e: print(name,type(e).__name__,str(e))
 time.sleep(1)
