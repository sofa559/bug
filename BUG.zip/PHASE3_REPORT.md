# Phase 3 執行報告

完成日期：2026-09-23。使用既有 Phase 2 inventory，沒有重新擴張爬取範圍。

**22 筆 Document metadata、20 份 TXT、19 份 raw HTML、12 份 raw PDF。9 份法規正確聚合為 9 個 regulation Document，沒有產生 72 份法規 TXT。**

實際資料與原本假設不同：一份 PDF 是沒有文字層的兩頁掃描影像；公告正文容器為空；八份 PDF 表格需複核，不能視為完全可用的欄位文字。

## A. 新增／修改檔案

- 新增 documents/__init__.py、cleaners.py、parsers.py、raw.py、pipeline.py。
- 新增 tests/test_documents.py、validate_documents.py。
- 修改 main.py、inventory/http_client.py、requirements.txt、README.md。
- 新增 PHASE3_GUIDE.md、本報告，以及 data/raw、data/processed 產物。
- Phase 2 inventory 與原始測試保留。

## B. 各檔案用途

| 檔案 | 責任 |
|---|---|
| main.py | 重用有效 inventory；參數決定刷新、offline、只做 Phase 2 |
| inventory/http_client.py | 既有 HTTP 流程新增完整串流下載的 opt-in，預設仍是 512 bytes |
| documents/cleaners.py | 保守清理、安全檔名、正文 SHA-256 與 duplicate 標記 |
| documents/parsers.py | HTML/公告/PDF/DOCX 解析與品質狀態，不連線 |
| documents/raw.py | raw 原件、manifest、快取 checksum、累積請求紀錄 |
| documents/pipeline.py | Source 聚合、Document 模型、父關係、錯誤隔離、TXT/metadata |
| documents/__init__.py | Python 套件標記 |
| tests/test_documents.py | 新增 15 個離線測試 |
| validate_documents.py | 核對本次產物、來源、條文、PDF、空公告與掃描 PDF |

各檔案 input/output、套件與重要 function 說明見 PHASE3_GUIDE.md。

## C. 新增套件

- PyMuPDF 1.28.2：以 `import pymupdf` 逐頁抽文字、取得簡單表格與頁面品質資訊。
- python-docx 1.2.0：DOCX 段落與表格的基本支援；本次只用離線合成檔驗證，實際沒有 DOCX。
- 沿用 requests、BeautifulSoup 與 Python 標準庫。
- 沒有安裝或執行 OCR、LibreOffice、LLM、RAG。

## D. 資料流

```text
有效的 sources.json
→ 依 scope_law_id 聚合 9 份法規
→ 建立公告與附件 Document plans，連接已知父文件
→ HTML 從 Phase 2 evidence 原樣保存至 raw
→ 已知附件正式下載至 raw（已存在則核對 checksum 重用）
→ HTML/PDF/DOCX parser
→ 保守 cleaning
→ 正文 SHA-256、重複標記
→ 非空正文 TXT + 所有 Document metadata
→ source_document_map + summary + validation
```

第一次正式處理有 14 次 HTTP 請求：12 個附件與兩個 robots；沒有外站或舊 HTTP 受阻來源請求。隨後 offline 重跑為 0 次請求，命中 31 份 raw。

## E. Source 如何聚合

- 72 個 law_system_page＝9 基本資料＋9 全文＋54 個別條文 → **9 個 regulation Document**。
- 基本資料提供標題／日期；全文頁提供全部正文；個別條文只保存 Source 關係，不另做 TXT。
- 1 公告 → 1 announcement metadata，雖然正文空仍保留父節點。
- 12 附件 URL → 12 attachment Document。
- 11 附件有可確認的母法規／母公告；直接由列表連到的掃描 PDF 無明確母文件，parent_document_id=null，未猜測。
- 52 外站與原受阻來源保留在來源映射中，document_ids=[]。

## F／G. 最後 Documents

| 類型 | Document 數 | TXT 數 |
|---|---:|---:|
| regulation | 9 | 9 |
| announcement | 1 | 0 |
| attachment | 12 | 11 |
| 合計 | **22** | **20** |

不替空公告或掃描 PDF 製造只有 header 的假正文 TXT。兩者 processed_file=null。

## H. PDF 解析結果

| 結果 | 數量 |
|---|---:|
| PDF 正式下載且可開啟 | 12 |
| 有抽出文字 | 11 |
| 嚴格 SUCCESS | 3 |
| 有文字但 TABLE_REVIEW_REQUIRED | 8 |
| OCR_REQUIRED、無文字 TXT | 1 |
| PDF PARSE_FAILED／DOWNLOAD_FAILED | 0 |

不能把「11 份有文字」寫成「11 份完全解析成功」。

## I. OCR_REQUIRED

1 份，Document ID `att_f9c837522a357774`：列表直接連到的「修正主管機關認定不宜於自助選物販賣機販售項目表」相關公告 PDF。

兩頁均為影像，PyMuPDF 每頁抽取 0 個有效字元。已用 Poppler 渲染並查看兩頁，確認不是下載失敗或空白頁。

完整 raw PDF 保留；沒有 OCR、手動補入全文或冒充 SUCCESS。原列表標題有明確「自113年10月14日生效」，因此 metadata 可保存 effective_date=2024-10-14，並標示證據來自 inventory_link_title；不是辨識掃描頁。

## J. duplicate

0。SHA-256 僅計算清理後正文，不含 TXT metadata header。相同 hash 才標記 duplicate，仍保留原件與文件；空內容不 hash。

這不表示完全沒有語意近似內容。本階段沒有做近似比對、跨格式改寫或版本合併。

## K. metadata.json 結構

頂層為 22 個 Document 的陣列，包括：

```text
document_id / title / document_type / source_name
source_ids[] / source_urls[] / primary_source_url / source_roles[]
categories[]
parent_document_id / parent_title / parent_document_ids[]
published_date / amended_date / effective_date / announcement_date
date_evidence[]
raw_files[] / raw_source_ids[] / processed_file
parse_status / review_flags[] / notes[]
content_hash / duplicate / duplicate_of
```

另保存條號順序、PDF 頁數與逐頁文字數、table_data。日期缺值保留 null；不混淆公布、修正、公告與生效。

整批狀態：

| parse_status | 數量 |
|---|---:|
| SUCCESS | 12（9 法規＋3 PDF） |
| EMPTY_CONTENT | 1 |
| OCR_REQUIRED | 1 |
| TABLE_REVIEW_REQUIRED | 8 |
| CONVERSION_REQUIRED | 0 |
| UNSUPPORTED | 0 |
| DOWNLOAD_FAILED | 0 |
| PARSE_FAILED | 0 |
| TEXT_REVIEW_REQUIRED | 0 |

新增 TEXT_REVIEW_REQUIRED 用於 U+FFFD 等文字解碼警示；本次未觸發。表格警示由合併/跨行欄位或偵測失敗觸發，不假裝欄位關係已完整重建。

## L. raw／processed

- data/raw/html：19 份原始 HTML。
- data/raw/pdf：12 份完整 PDF。
- data/raw/word：0 DOC、0 DOCX。
- data/raw/other：0 其他格式。
- data/raw/manifest.json：原件 URL、Source ID、headers、bytes hash、时间、快照来源。
- data/raw/requests_history.json：累積下載紀錄。
- data/processed：20 TXT、metadata.json、source_document_map.json、summary.json、當次 requests.json、validation.json/md、manual_review.json。

檔名使用穩定 ID 加安全截短標題。同名「附表.PDF」的 raw 使用不同 Source ID，TXT 使用不同 Document ID，沒有覆蓋。

## M. 測試結果

- 原 Phase 2：16 個單元測試仍通過。
- 新 Phase 3：15 個單元測試通過。
- 合計：**31/31**。
- Phase 2 產物驗證：**27/27**。
- Phase 3 產物驗證：**59/59**。
- offline 重跑：raw cache hits=31、requests=0；Document ID、正文 hash、TXT 路徑不變。

測試涵蓋 cleaning、檔名、正文 hash、duplicate、9份聚合、PDF magic、DOCX 表格、解析狀態、父關係、完整串流/大小限制、快取完整性、受阻不請求、單份損坏後繼續下一份。

## N. 人工與實際抽查

### 三份法規

1. 自助選物販賣事業管理自治條例：10 條；公布 2022-11-30，生效 2023-09-01；條號順序、主管機關、距離、裁罰文字保留。
2. 工業產品展示服務業等認定列管及輔導作業要點：7 點；公布 2019-06-28；三份附件與母文件可追溯。
3. 違反工廠管理輔導法事件裁罰基準：3 點；修正 2025-10-31；第三點指向附表，完整表格作獨立附件文件，不混進母法規正文。

以上均對照原 HTML，另自動檢查全部 9 份的每個 pre 是否依序出現在 TXT，沒有 menu/footer。

### 三份 PDF 加一份掃描例外

- 規定.pdf：查看全 1 頁；標題及三點正文與 TXT 一致、可讀，SUCCESS。
- 電子遊戲場業逾期不履行怠金附表：查看全 1 頁；原表四次不履行與金額關係清楚，TXT 跨欄交錯，保留 TABLE_REVIEW_REQUIRED。
- 商業登記法裁罰附表：查看全 2 頁；有跨頁欄位、備註及少量抽取重複字，保留 TABLE_REVIEW_REQUIRED，不把它當成可靠欄值表。
- 掃描公告：查看全 2 頁，原件有公文、印章與項目表但沒有文字層；OCR_REQUIRED。

視覺檢查以 pdftoppm 100 dpi 渲染；工具有缺少 Symbol/ArialUnicode 字型提示，但實際抽查圖中的繁體文字可讀。人工記錄保存 raw hash，確保對應同一原件。

### 一份公告

公告日期 2023-08-10，標題寫明生效 2023-09-01；`.worddisaplay` 正文為空。保留 EMPTY_CONTENT metadata、原標題 announcement_statement 與兩個 PDF 的 parent relationship；沒有自行生成正文。

## O. 問題與 unknown

- 原 Phase 2 的 HTTP robots_blocked 舊來源沒有重試；現行有效內容目前無法確認。
- 表格 TXT 的欄位對應尚未可靠重建；需人工核對，原表格與 table_data 都保留。
- 掃描 PDF 未 OCR，因此正文仍缺。
- 沒有實際 DOCX/DOC/其他格式樣本。DOCX 僅基本離線測試通過，不能宣稱所有政府 Word 文件已驗證。
- 52 個外站來源沒有內容文件，完全遵守排除範圍。

## P. Phase 4 前風險

1. 不能把 20 份 TXT 全部無差別匯入：8 份需表格複核，1 掃描文件沒有 TXT。
2. 明確決定後續是否 OCR；本階段沒有執行。
3. 日期意義與版本現行性要分開。HTML 是 Phase 2 快照，PDF 是本次下載，不能宣稱已審查法律有效性或版本一致。
4. 近似重複與不同版本仍可能存在，exact hash 只處理完全相同正文。
5. 表格包含裁罰金額與条件，欄位錯配會影響問答；需保留 raw 追查。
6. 組員應以 metadata 的文件邊界、來源與品質狀態選取資料，再決定切分與 RAG 流程。

**停在 Phase 3，沒有執行 Phase 4、OCR、LightRAG、Knowledge Graph、embedding、LLM 或 API。**
