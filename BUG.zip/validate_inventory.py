"""離線驗證 Phase 2 輸出：只讀 JSON/CSV/HTML 證據，產生 validation.json/md。"""

import csv
import json
from pathlib import Path
from urllib.parse import urlsplit

from bs4 import BeautifulSoup

from inventory.urls import START_URL, allowed, normalize_url


def validate(directory="data/inventory"):
    """命令列入口呼叫；input 是輸出目錄，output 是驗證報告與 assertion 結果。

    對照保存的 HTML 查連結及文字，獨立於 crawler 的解析結果；不把「檔案存在」
    當成資料正確。已知失敗與 unknown 是報告事項，不擅自從 inventory 刪掉。
    """
    p = Path(directory)
    records = json.loads((p / "sources.json").read_text(encoding="utf-8"))
    summary = json.loads((p / "summary.json").read_text(encoding="utf-8"))
    events = json.loads((p / "requests.json").read_text(encoding="utf-8"))
    with (p / "sources.csv").open(encoding="utf-8-sig", newline="") as f:
        csv_rows = list(csv.DictReader(f))
    by_url = {r["source_url"]: r for r in records}
    checks = []

    def check(label, condition):
        checks.append({"check": label, "passed": bool(condition)})

    check("JSON 與 CSV 筆數一致", len(records) == len(csv_rows) == summary["total_urls"])
    check("id 與 source_url 唯一", len({r["id"] for r in records}) == len(by_url) == len(records))
    check("CSV 多值欄位與 JSON 完全一致", all(json.loads(c["categories"]) == r["categories"] and json.loads(c["discovery_edges"]) == r["discovery_edges"] for r, c in zip(records, csv_rows)))
    check("所有實際請求均為允許官方網域", all(allowed(e["url"]) for e in events))
    check("沒有請求 related/search/portal/external skipped 來源", all(not any(e["url"] == r["source_url"] for e in events) for r in records if r["source_type"] in {"external_skipped", "related_page_skipped", "search_skipped", "portal_skipped"}))
    check("所有引用都能回連 inventory", all(u in by_url for r in records for field in ["parent_urls", "regulation_urls", "discovered_from"] for u in r[field]))
    check("非根來源都有發現位置", all(r["discovered_from"] for r in records if r["source_url"] != START_URL))
    check("所有分類條目數符合網站總筆數", all(g["matches_reported_total"] for g in summary["categories"].values()))
    expected_categories = {"公司登記", "商業登記", "工廠登記", "電器承裝業登記", "動產擔保登記"}
    check("五個子分類全部探索", expected_categories <= set(summary["categories"]))
    check("沒有 pending 或中止", summary["pending"] == 0 and not summary["interrupted"])
    check("附件皆只檢查最多 512 bytes", all((r["bytes_inspected"] or 0) <= 512 for r in records if r["source_type"] == "direct_attachment"))
    check("已檢查 PDF 的 magic 證據未因重複發現遺失", all("magic:%PDF-" in (r["format_evidence"] or []) for r in records if r["source_type"] == "direct_attachment" and r["file_type"] == "pdf" and r["crawl_status"] == "success"))
    check("URL 未因舊編碼轉出 replacement character", all("%EF%BF%BD" not in r["source_url"].upper() and "\ufffd" not in r["source_url"] for r in records))
    check("跳過外站有 title/category/來源位置", all(r["title"] and r["categories"] and r["discovered_from"] and r["http_status"] is None for r in records if r["source_type"] == "external_skipped"))

    soup_cache = {}
    def soup_for(record):
        path = record.get("evidence_html")
        if not path:
            return None
        if path not in soup_cache:
            soup_cache[path] = BeautifulSoup(Path(path).read_bytes(), "html.parser")
        return soup_cache[path]

    def verify_sample(record, group):
        matched_edges = []
        for edge in record["discovery_edges"]:
            parent = by_url.get(edge["from_url"])
            soup = soup_for(parent) if parent else None
            if not soup:
                continue
            for a in soup.select("main#main .item > a, .content2 a[href], .content .fileZone a[href]"):
                if normalize_url(edge["from_url"], a.get("href")) == edge["original_url"]:
                    text = a.get_text(" ", strip=True)
                    if edge["link_text"] == text:
                        matched_edges.append(edge)
                        break
        ok = bool(matched_edges) and bool(record["title"]) and bool(record["categories"])
        if record["source_type"] == "direct_attachment":
            if any(e["relation"] == "attachment" for e in matched_edges):
                ok = ok and bool(record["parent_urls"])
            ok = ok and any(e["url"] == record["source_url"] and e.get("http_status") == 200 and e.get("bytes_read", 9999) <= 512 for e in events)
        check(f"{group}：{record['title']}", ok)
        return {"group": group, "id": record["id"], "title": record["title"], "categories": record["categories"], "source_type": record["source_type"], "source_url": record["source_url"], "parent_urls": record["parent_urls"], "regulation_urls": record["regulation_urls"], "crawl_status": record["crawl_status"], "filename": record["filename"], "file_type": record["file_type"], "matched_html_edges": matched_edges, "passed": bool(ok)}

    samples = []
    for category in sorted(expected_categories):
        group = summary["categories"].get(category)
        if group:
            samples.append(verify_sample(by_url[group["entries"][0]], "一般來源"))
    law_samples = [r for r in records if r["source_type"] == "law_system_page" and any(e["relation"] == "list_item" for e in r["discovery_edges"])][:3]
    samples.extend(verify_sample(r, "新北市法規系統") for r in law_samples)
    files = [r for r in records if r["source_type"] == "direct_attachment"]
    for pattern in ["/Api/Upload/Download", "/DownloadNews.ashx", "/Download.ashx"]:
        candidates = [r for r in files if pattern in r["source_url"]]
        if candidates:
            samples.append(verify_sample(candidates[0], "附件"))
    externals = [r for r in records if r["source_type"] == "external_skipped"]
    if externals:
        samples.append(verify_sample(externals[0], "外站略過"))
    check("至少抽查 5 一般 + 3 法規 + 3 附件 + 1 外站", all(sum(s["group"] == group for s in samples) >= count for group, count in [("一般來源", 5), ("新北市法規系統", 3), ("附件", 3), ("外站略過", 1)]))
    issues = [{"title": r["title"], "url": r["source_url"], "type": r["source_type"], "status": r["crawl_status"], "notes": r["notes"]} for r in records if r["source_type"] == "unknown" or r["crawl_status"] not in {"success", "external_skipped", "skipped_scope"}]
    report = {"passed": all(c["passed"] for c in checks), "checks": checks, "samples": samples, "issues": issues, "interpretation": "一般來源從五個子分類各抽一筆；外部法規以來源列表 HTML 驗證，不連線外站。failed/unknown 另列，不等同驗證程式出錯。"}
    (p / "validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# Phase 2 清單驗證", "", f"資料結構與抽查：{'通過' if report['passed'] else '有未通過項目'}。", "", report["interpretation"], "", "## 全部檢查", ""]
    lines.extend(f"- {'PASS' if c['passed'] else 'FAIL'}：{c['check']}" for c in checks)
    lines.extend(["", "## 抽查紀錄", ""])
    for sample in samples:
        lines.extend([f"### {sample['group']}：{sample['title']}", "", f"- 分類：{'、'.join(sample['categories'])}", f"- 類型：`{sample['source_type']}`；狀態：`{sample['crawl_status']}`", f"- URL：<{sample['source_url']}>", f"- 父頁：{json.dumps(sample['parent_urls'], ensure_ascii=False)}", f"- 檔名／格式：{sample['filename']} / {sample['file_type']}", "- 已對照保存的 HTML 連結與顯示名稱。", ""])
    lines.extend(["## 需注意的 unknown / failed", "", json.dumps(issues, ensure_ascii=False, indent=2)])
    (p / "validation.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Validation: {sum(c['passed'] for c in checks)}/{len(checks)} passed; {len(samples)} samples; {len(issues)} issues")
    if not report["passed"]:
        for check_result in checks:
            if not check_result["passed"]:
                print("FAIL", check_result["check"])
        raise SystemExit(1)
    return report


if __name__ == "__main__":
    validate()
