"""保守清理與命名：保留法規句子、條號、數字與表格的內部空白。"""

import hashlib
import re


def clean_text(text):
    """所有 parser 呼叫；input 原始文字 → output 清理文字。

    只統一換行、移除無意義控制字元、行尾空白和過多空行。不摘要、不改寫、
    不移除頁碼/金額/日期，也不強行接合斷行或壓縮表格欄間空白。
    """
    text = text.replace("\r\r\n", "\n").replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\ufeff", "").replace("\u200b", "").replace("\xa0", " ")
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)
    text = "\n".join(line.rstrip() for line in text.split("\n"))
    return re.sub(r"\n[ \t]*\n(?:[ \t]*\n)+", "\n\n", text).strip()


def safe_filename(title, limit=65):
    """輸出層呼叫；input 顯示名稱 → Windows 安全短檔名，ID 另加以避免同名覆蓋。"""
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", title or "未提供標題")
    value = re.sub(r"\s+", " ", value).strip(" .")[:limit].rstrip(" .") or "未提供標題"
    if re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", value):
        value = "_" + value
    return value


def content_hash(text):
    """輸出層呼叫；只 hash 清理後正文，排除 TXT metadata header；空文字回 None。"""
    body = clean_text(text)
    return hashlib.sha256(body.encode("utf-8")).hexdigest() if body else None


def mark_duplicates(documents):
    """pipeline 呼叫；input/原地 output 為 Documents，完全相同且非空正文保留並標記。"""
    first = {}
    for document in sorted(documents, key=lambda d: d["document_id"]):
        digest = document["content_hash"]
        document.update(duplicate=False, duplicate_of=None)
        if not digest:
            continue
        if digest in first:
            document.update(duplicate=True, duplicate_of=first[digest])
        else:
            first[digest] = document["document_id"]
