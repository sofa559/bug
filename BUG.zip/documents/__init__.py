"""Phase 3：Source 聚合成 Document、保存 raw、解析文字；不執行 RAG 或 OCR。"""
