"""只做 raw → 文字/metadata；不連線、不自行擴張来源範圍。"""

import re
import zipfile
from datetime import date
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

import pymupdf
from bs4 import BeautifulSoup
from docx import Document as WordDocument
from docx.table import Table

from documents.cleaners import clean_text


def detect_file_type(path, filename=None, content_type=None):
    """pipeline 呼叫；input 完整 raw/HTTP 提示 → 格式與判斷證據。

    PDF 用 magic；DOCX 檢查 ZIP 內部結構，不把所有 ZIP 都當 Word。
    OLE 只有配合 .doc/.xls 提示才判 subtype；未知仍保存，不假裝可解析。
    """
    p = Path(path)
    with p.open("rb") as stream:
        head = stream.read(1024)
    if head.lstrip().startswith((b"<!DOCTYPE html", b"<html", b"<!doctype html")):
        return "html", ["HTML_response_instead_of_attachment"]
    if b"%PDF-" in head[:1024]:
        return "pdf", ["magic:%PDF-"]
    ext = Path(filename or "").suffix.lower().lstrip(".")
    if not ext:
        ext = {"application/msword": "doc", "application/vnd.ms-excel": "xls"}.get((content_type or "").split(";")[0].lower(), "")
    if head.startswith(b"PK") and zipfile.is_zipfile(p):
        with zipfile.ZipFile(p) as archive:
            names = set(archive.namelist())
            if "[Content_Types].xml" in names and "word/document.xml" in names:
                return "docx", ["ZIP:word/document.xml"]
            if "xl/workbook.xml" in names:
                return "xlsx", ["ZIP:xl/workbook.xml"]
            if "mimetype" in names and archive.getinfo("mimetype").file_size < 256:
                mime = archive.read("mimetype").decode("ascii", errors="replace")
                if mime == "application/vnd.oasis.opendocument.text":
                    return "odt", ["ZIP:mimetype=odt"]
        return "zip", ["ZIP_container"]
    if head.startswith(bytes.fromhex("d0cf11e0a1b11ae1")):
        return (ext if ext in {"doc", "xls"} else "ole"), ["OLE_container", "filename_hint:" + ext]
    if ext:
        return ext, ["filename_hint_only", "content_type:" + (content_type or "unknown")]
    return "unknown", ["unrecognized_magic", "content_type:" + (content_type or "unknown")]


def chinese_number(text):
    """日期 parser 呼叫；阿拉伯或常見中文整數→int，僅供明確年月日，不推算相對日期。"""
    if text.isdigit():
        return int(text)
    digits = dict(zip("零〇一二三四五六七八九", [0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))
    if all(c in digits for c in text):
        return int("".join(str(digits[c]) for c in text))
    result = current = 0
    for char in text:
        if char in digits:
            current = digits[char]
        elif char in {"十", "百", "千"}:
            result += (current or 1) * {"十": 10, "百": 100, "千": 1000}[char]
            current = 0
        else:
            raise ValueError("未知中文日期數字")
    return result + current


DATE_NUM = r"[0-9零〇一二三四五六七八九十百千]+"
DATE_RE = re.compile(rf"(?:中華民國|民國)?\s*({DATE_NUM})\s*年\s*({DATE_NUM})\s*月\s*({DATE_NUM})\s*日")


def parse_date(text, roc=True):
    """HTML parser 呼叫；明確日期文字→ISO 日期或 None；不由公告日期推測生效日。"""
    match = DATE_RE.search(text or "") or re.search(r"(\d{2,4})[./-](\d{1,2})[./-](\d{1,2})", text or "")
    if not match:
        return None
    try:
        year, month, day = (chinese_number(v) for v in match.groups())
        if roc and year < 1000:
            year += 1911
        return date(year, month, day).isoformat()
    except ValueError:
        return None


def explicit_effective_date(text):
    """只擷取正文中明寫的『自某年某月某日施行/生效』；相對生效日回 None。"""
    compact = re.sub(r"\s+", "", text)
    pattern = rf"自((?:中華民國|民國)?{DATE_NUM}年{DATE_NUM}月{DATE_NUM}日)(?:起)?(?:施行|生效)"
    matches = re.findall(pattern, compact)
    values = {parse_date(value) for value in matches} - {None}
    return (next(iter(values)), matches[0]) if len(values) == 1 else (None, None)


def parse_regulation(full_html, basic_html=None):
    """pipeline 呼叫；全文 HTML＋基本資料 HTML → 一份完整正文與各語意日期。

    每個 pre 依原 DOM 順序保留，條號來自同一列 col-th；不讀 menu/footer。
    基本資料只供標題/日期，不另建 TXT。
    """
    soup = BeautifulSoup(full_html, "html.parser")
    title_node = soup.select_one("#cph_content_lawheader_hlkLNNAME")
    paragraphs = soup.select(".content2 td.col-td pre")
    if not title_node or not paragraphs:
        raise ValueError("所有條文頁缺少已確認的標題或正文結構")
    metadata = {"title": title_node.get_text(" ", strip=True), "published_date": None, "amended_date": None, "effective_date": None, "date_evidence": [], "article_labels": [], "article_numbers": []}
    if basic_html:
        basic = BeautifulSoup(basic_html, "html.parser")
        for row in basic.select(".c-law table.tab-edit tr"):
            label, value = row.find("th"), row.find("td")
            if not label or not value:
                continue
            label, value = label.get_text(strip=True), value.get_text(" ", strip=True)
            field = "published_date" if "公發布時間" in label else "amended_date" if "修正時間" in label else None
            if field:
                metadata[field] = parse_date(value)
                metadata["date_evidence"].append({"field": field, "label": label, "text": value, "origin": "basic_html"})
    # 只在名稱/日期儲存格明确標示公發布或修正時補日期，兩者不混用。
    header = soup.select_one("#cph_content_lawheader_law")
    header_text = header.get_text(" ", strip=True) if header else ""
    for label, field in [("公發布", "published_date"), ("修正", "amended_date")]:
        if label in header_text and metadata[field] is None:
            metadata[field] = parse_date(header_text)
            metadata["date_evidence"].append({"field": field, "label": label, "text": header_text, "origin": "all_articles_html"})
    chunks = []
    for pre in paragraphs:
        row = pre.find_parent("tr")
        label_node = row.select_one("td.col-th a") if row else None
        label = clean_text(label_node.get_text(" ", strip=True)) if label_node else None
        body = clean_text(pre.get_text())
        metadata["article_labels"].append(label)
        number = dict(parse_qsl(urlsplit(label_node.get("href", "")).query)).get("flno") if label_node else None
        metadata["article_numbers"].append(number)
        chunks.append((label + "\n" if label else "") + body)
    text = clean_text("\n\n".join(chunks))
    effective, evidence = explicit_effective_date(text)
    metadata["effective_date"] = effective
    if evidence:
        metadata["date_evidence"].append({"field": "effective_date", "label": "施行/生效", "text": evidence, "origin": "all_articles_body"})
    return {"text": text, "parse_status": "SUCCESS" if text else "EMPTY_CONTENT", "notes": [], "metadata": metadata}


def parse_announcement(html):
    """pipeline 呼叫；公告 DOM → 真實正文與公告 metadata，空容器不以標題冒充正文。"""
    soup = BeautifulSoup(html, "html.parser")
    heading = soup.select_one(".content .edit-title .lawname")
    content = soup.select_one(".content .worddisaplay")
    when = soup.select_one(".content .edit-title .col-th")
    if heading is None or content is None:
        raise ValueError("公告缺少已確認的內容結構")
    title = heading.get_text(" ", strip=True)
    raw_date = when.get_text(strip=True) if when else None
    text = clean_text(content.get_text("\n", strip=True))
    effective, evidence = explicit_effective_date(title + "\n" + text)
    meta = {"title": title, "announcement_date": parse_date(raw_date), "effective_date": effective, "announcement_statement": title, "date_evidence": []}
    if raw_date:
        meta["date_evidence"].append({"field": "announcement_date", "label": "公告日期", "text": raw_date, "origin": "announcement_html"})
    if evidence:
        meta["date_evidence"].append({"field": "effective_date", "label": "生效", "text": evidence, "origin": "announcement_heading_or_body"})
    return {"text": text, "parse_status": "SUCCESS" if text else "EMPTY_CONTENT", "metadata": meta, "notes": [] if text else ["公告正文 .worddisaplay 為空；原始公告標題保存在 announcement_statement，不製造正文 TXT。"]}


def parse_pdf(path):
    """pipeline 呼叫；PDF raw → 逐頁文字、頁面品質、簡單表格資料與解析狀態。

    不 OCR、不重建複雜表格。表格 extract 結果另存 metadata，原始頁面文字保留。
    含影像/圖形且文字少於 20 字的頁面保守列為需 OCR 人工確認，不能冒充全文成功。
    """
    chunks, pages, tables, flags, notes = [], [], [], set(), []
    with pymupdf.open(path) as pdf:
        if pdf.needs_pass:
            raise ValueError("PDF 需要密碼，未繞過保護")
        for index, page in enumerate(pdf):
            text = clean_text(page.get_text("text", sort=True))
            count = len(re.sub(r"\s", "", text))
            images = len(page.get_images())
            drawings = len(page.get_drawings())
            missing_text = count < 20 and bool(images or drawings)
            if missing_text:
                flags.add("OCR_REQUIRED")
            if "\ufffd" in text:
                flags.add("TEXT_REVIEW_REQUIRED")
            page_info = {"page": index + 1, "text_characters": count, "images": images, "drawings": drawings, "ocr_candidate": missing_text}
            pages.append(page_info)
            chunks.append(text)
            try:
                found = page.find_tables()
                for table in found.tables:
                    rows = table.extract()
                    complex_cells = any(cell is None or "\n" in (cell or "") for row in rows for cell in row)
                    tables.append({"page": index + 1, "bbox": list(table.bbox), "rows": rows, "review_required": complex_cells})
                    if complex_cells:
                        flags.add("TABLE_REVIEW_REQUIRED")
            except Exception as exc:
                flags.add("TABLE_REVIEW_REQUIRED")
                notes.append(f"第 {index + 1} 頁表格偵測失敗：{type(exc).__name__}: {exc}")
    body = clean_text("\n\n".join(chunks))
    if "OCR_REQUIRED" in flags:
        status = "OCR_REQUIRED"
        notes.append("部分頁含影像/圖形但有效文字不足；需確認掃描/文字層，不執行 OCR。若有部分文字則保留並明示不完整。")
    elif not body:
        status = "EMPTY_CONTENT"
    elif "TEXT_REVIEW_REQUIRED" in flags:
        status = "TEXT_REVIEW_REQUIRED"
    elif "TABLE_REVIEW_REQUIRED" in flags:
        status = "TABLE_REVIEW_REQUIRED"
    else:
        status = "SUCCESS"
    if "TABLE_REVIEW_REQUIRED" in flags:
        notes.append("表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。")
    return {"text": body, "parse_status": status, "notes": notes, "metadata": {"page_count": len(pages), "page_quality": pages, "table_data": tables, "review_flags": sorted(flags)}}


def parse_docx(path):
    """pipeline 呼叫；DOCX raw → 按文件順序的段落與表格文字，僅基本支援。"""
    doc = WordDocument(path)
    chunks, tables = [], []
    flags = set()
    for block in doc.iter_inner_content():
        if isinstance(block, Table):
            rows = [[clean_text(cell.text) for cell in row.cells] for row in block.rows]
            tables.append({"rows": rows})
            chunks.append("\n".join("\t".join(row) for row in rows))
            if any(cell.grid_span > 1 for row in block.rows for cell in row.cells) or block._tbl.xpath('.//w:vMerge'):
                flags.add("TABLE_REVIEW_REQUIRED")
        else:
            chunks.append(block.text)
    text = clean_text("\n\n".join(chunks))
    status = "TABLE_REVIEW_REQUIRED" if flags and text else "SUCCESS" if text else "EMPTY_CONTENT"
    return {"text": text, "parse_status": status, "notes": ["DOCX 合併儲存格需人工核對。"] if flags else [], "metadata": {"table_data": tables, "review_flags": sorted(flags)}}


def parse_attachment(path, file_type):
    """pipeline 的統一入口；依真實格式呼叫 parser，失敗回狀態而不終止整批工作。"""
    try:
        if file_type == "pdf":
            return parse_pdf(path)
        if file_type == "docx":
            return parse_docx(path)
        return {"text": "", "parse_status": "CONVERSION_REQUIRED" if file_type == "doc" else "UNSUPPORTED", "metadata": {}, "notes": ["原始檔已保存，本階段不轉檔或解析此格式。"]}
    except Exception as exc:
        return {"text": "", "parse_status": "PARSE_FAILED", "metadata": {}, "notes": [f"{type(exc).__name__}: {exc}"]}
