"""保存可重現的 raw；重用 Phase 2 HttpClient，不另寫 requests 流程。"""

import hashlib
import json
from datetime import datetime, timezone
from email.message import Message
from pathlib import Path

from documents.parsers import detect_file_type
from inventory.http_client import HttpClient
from inventory.urls import allowed


def file_hash(path):
    """RawStore/驗證器呼叫；原始檔 bytes→SHA-256，用於快取完整性，不是正文去重。"""
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


class RawUnavailable(Exception):
    """讓 pipeline 區分下載失敗與 parser 失敗，並保留可取得的錯誤回應/部分檔案。"""
    def __init__(self, message, raw_file=None):
        super().__init__(message)
        self.raw_file = raw_file


class RawStore:
    def __init__(self, root="data/raw", offline=False, refresh=False, client=None):
        self.root = Path(root)
        self.offline, self.refresh = offline, refresh
        self.client = client or HttpClient()
        self.manifest_path = self.root / "manifest.json"
        self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8")) if self.manifest_path.exists() else {}
        self.cache_hits = 0
        for folder in ["html", "pdf", "word", "other"]:
            (self.root / folder).mkdir(parents=True, exist_ok=True)

    def cached(self, source):
        """html/attachment 呼叫；source ID→通過 bytes hash 核對的快取，否則 None。"""
        item = self.manifest.get(source["id"])
        if not self.refresh and item and item["source_url"] == source["source_url"]:
            path = Path(item["path"])
            if path.resolve().is_relative_to(self.root.resolve()) and path.exists() and file_hash(path) == item["raw_sha256"]:
                self.cache_hits += 1
                return item
        return None

    def record(self, source, path, kind, provenance, headers=None, evidence=None):
        """raw 成功保存後呼叫；來源+檔案→manifest entry，立即保存避免中斷丟失下載成果。"""
        item = {"source_id": source["id"], "source_url": source["source_url"], "path": path.as_posix(), "file_type": kind,
                "raw_sha256": file_hash(path), "size_bytes": path.stat().st_size, "saved_at": datetime.now(timezone.utc).isoformat(),
                "source_observed_at": source.get("observed_at"), "provenance": provenance, "headers": headers or {}, "format_evidence": evidence or []}
        self.manifest[source["id"]] = item
        self.manifest_path.write_text(json.dumps(self.manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        return item

    def permitted(self, source):
        """任何網路/證據使用前確認 inventory scope；受阻與外站不重試。"""
        if not allowed(source["source_url"]) or source["crawl_status"] != "success":
            raise RawUnavailable(f"保留 inventory 狀態 {source['crawl_status']}，本階段不請求。")

    def html(self, source):
        """pipeline 呼叫；Source→raw HTML manifest，優先複製 Phase 2 原始 response bytes。"""
        self.permitted(source)
        cached = self.cached(source)
        if cached:
            return cached
        path = self.root / "html" / (source["id"] + ".html")
        evidence_path = Path(source["evidence_html"]) if source.get("evidence_html") else None
        if not self.refresh and evidence_path and evidence_path.exists():
            path.write_bytes(evidence_path.read_bytes())
            return self.record(source, path, "html", "inventory_evidence:" + evidence_path.as_posix())
        if self.offline:
            raise RawUnavailable("offline 模式沒有此來源的 raw/HTML evidence。")
        result = self.client.fetch(source["source_url"], guard=lambda u: allowed(u) and u == source["source_url"])
        if result["status"] != "ok" or not result.get("is_html"):
            raise RawUnavailable(f"HTML 取得失敗：{result['status']} {result.get('http_status')}")
        path.write_bytes(result["body"])
        return self.record(source, path, "html", "http_response", result.get("headers"))

    def attachment(self, source):
        """pipeline 呼叫；Source→完整 raw manifest；不以附表.PDF 作唯一檔名，避免覆蓋。"""
        self.permitted(source)
        cached = self.cached(source)
        if cached:
            return cached
        if self.offline:
            raise RawUnavailable("offline 模式沒有此附件 raw。")
        temporary = self.root / "other" / (source["id"] + ".download")
        result = self.client.fetch(source["source_url"], attachment=True, download_path=temporary, guard=allowed)
        if result["status"] != "ok":
            partial = temporary.with_suffix(temporary.suffix + ".part")
            raise RawUnavailable(f"附件下載失敗：{result['status']} {result.get('http_status')}", partial.as_posix() if partial.exists() else None)
        if result.get("is_html"):
            error_path = self.root / "other" / (source["id"] + "_response.html")
            error_path.write_bytes(result.get("body", b""))
            raise RawUnavailable("附件端點回傳 HTML，未當成 PDF 解析。", error_path.as_posix())
        headers = result.get("headers", {})
        message = Message()
        message["Content-Disposition"] = headers.get("content-disposition", "")
        response_filename = message.get_filename() or source.get("filename")
        kind, evidence = detect_file_type(temporary, response_filename, headers.get("content-type"))
        if kind == "html":
            raise RawUnavailable("下載內容是 HTML，未當成附件正文。", temporary.as_posix())
        folder = "pdf" if kind == "pdf" else "word" if kind in {"doc", "docx"} else "other"
        extension = kind if kind.isalnum() and len(kind) <= 8 and kind != "unknown" else "bin"
        target = self.root / folder / (source["id"] + "." + extension)
        temporary.replace(target)
        return self.record(source, target, kind, "http_response", result.get("headers"), evidence)

    def close(self):
        history_path = self.root / "requests_history.json"
        history = json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else []
        history.extend(self.client.events)
        history_path.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
        self.client.close()
