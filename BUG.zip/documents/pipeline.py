"""Source → Document 主流程；聚合、raw、parser、metadata、TXT、內容去重。"""

import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

from documents.cleaners import clean_text, content_hash, mark_duplicates, safe_filename
from documents.parsers import explicit_effective_date, parse_announcement, parse_attachment, parse_regulation
from documents.raw import RawStore, RawUnavailable


def read_inventory(path="data/inventory/sources.json"):
    """main 呼叫；有效且唯一的 Source 陣列→records。錯誤清單不默默重爬，以免掩蓋問題。"""
    sources = json.loads(Path(path).read_text(encoding="utf-8"))
    required = {"id", "title", "source_url", "source_type", "crawl_status", "categories"}
    if not isinstance(sources, list) or not sources or any(not isinstance(s, dict) or not required <= s.keys() for s in sources):
        raise ValueError("sources.json 不是有效的 Source Inventory；請檢查檔案或使用 --refresh-inventory。")
    if len({s["id"] for s in sources}) != len(sources) or len({s["source_url"] for s in sources}) != len(sources):
        raise ValueError("inventory id/URL 重複，請先修正 Phase 2。")
    return sources


def make_document(key, kind, sources, primary):
    """group_sources 呼叫；來源組→獨立 Document 模型，缺值 null，Source 不直接當 Document。"""
    return {"document_id": kind[:3] + "_" + hashlib.sha256(key.encode()).hexdigest()[:16], "title": primary.get("title"),
            "document_type": kind, "source_name": "新北市法規系統" if urlsplit(primary["source_url"]).hostname == "web.law.ntpc.gov.tw" else "新北市政府經濟發展局",
            "source_ids": [s["id"] for s in sources], "source_urls": [s["source_url"] for s in sources], "primary_source_url": primary["source_url"],
            "categories": sorted({c for s in sources for c in s.get("categories", [])}), "parent_document_id": None, "parent_title": None, "parent_document_ids": [],
            "published_date": None, "amended_date": None, "effective_date": None, "announcement_date": None, "date_evidence": [],
            "raw_files": [], "raw_source_ids": [], "processed_file": None, "parse_status": "NOT_PROCESSED", "duplicate": False, "duplicate_of": None,
            "content_hash": None, "notes": [], "review_flags": [], "file_type": "html" if kind != "attachment" else None,
            "source_roles": [{"source_id": s["id"], "url": s["source_url"], "role": "basic_metadata" if "FLAWDAT01.aspx" in s["source_url"] else "complete_body" if "FLAWDAT0202.aspx" in s["source_url"] else "article_reference_only" if "FLAWDOC01.aspx" in s["source_url"] else s["source_type"]} for s in sources]}


def group_sources(sources):
    """pipeline 呼叫；inventory→Document plans。以 scope_law_id 聚合；不從相似標題猜母法規。

    全文頁為 primary；全部個別條文 source ID 保留，但不額外建 Document。
    公告即使空正文仍保留 Document metadata，提供附件父節點。
    """
    law_groups = defaultdict(list)
    plans = []
    by_url = {}
    for source in sources:
        if source["source_type"] == "law_system_page" and source.get("scope_law_id") and source["crawl_status"] == "success":
            law_groups[source["scope_law_id"]].append(source)
    for key, members in sorted(law_groups.items()):
        complete = [s for s in members if urlsplit(s["source_url"]).path.lower().endswith("/flawdat0202.aspx")]
        basic = [s for s in members if urlsplit(s["source_url"]).path.lower().endswith("/flawdat01.aspx")]
        primary = (complete or basic or members)[0]
        doc = make_document("law:" + key, "regulation", members, primary)
        doc["law_id"] = key
        plans.append({"document": doc, "sources": members, "primary": primary, "basic": basic[0] if basic else None, "complete": complete[0] if complete else None})
        for source in members:
            by_url[source["source_url"]] = doc
    for source in sources:
        if source["source_type"] == "announcement_page" and source["crawl_status"] == "success":
            doc = make_document(source["source_url"], "announcement", [source], source)
            plans.append({"document": doc, "sources": [source], "primary": source})
            by_url[source["source_url"]] = doc
    for source in sources:
        if source["source_type"] != "direct_attachment":
            continue
        doc = make_document(source["source_url"], "attachment", [source], source)
        parent_urls = source.get("regulation_urls", []) + source.get("parent_urls", [])
        parents = {by_url[url]["document_id"]: by_url[url] for url in parent_urls if url in by_url}
        if parents:
            parent = next(iter(parents.values()))
            doc.update(parent_document_id=parent["document_id"], parent_title=parent["title"], parent_document_ids=list(parents))
            doc["title"] = (parent["title"] or "") + "－" + (source.get("filename") or source.get("title") or source["id"])
        else:
            doc["notes"].append("附件由列表直接連結，inventory 未提供可確認的母法規/母公告；parent_document_id 保留 null，不依標題猜測。")
        doc["original_filename"] = source.get("filename")
        effective, date_text = explicit_effective_date(source.get("title") or "")
        if effective:
            doc["effective_date"] = effective
            doc["date_evidence"].append({"field": "effective_date", "label": "生效", "text": date_text, "origin": "inventory_link_title"})
        plans.append({"document": doc, "sources": [source], "primary": source})
    return plans


def write_text_document(document, text, directory):
    """pipeline 呼叫；Document＋清理後正文→唯一 TXT。空/失敗內容不輸出假正文檔。"""
    body = clean_text(text)
    document["content_hash"] = content_hash(body)
    document["body_character_count"] = len(body)
    if not body:
        return
    fields = [("標題", "title"), ("來源", "source_name"), ("文件類型", "document_type"), ("母法規／母公告", "parent_title"),
              ("來源網址", "primary_source_url"), ("公布日期", "published_date"), ("修正日期", "amended_date"),
              ("公告日期", "announcement_date"), ("生效日期", "effective_date"), ("解析狀態", "parse_status")]
    header = [f"文件 ID：{document['document_id']}"] + [f"{label}：{document[key]}" for label, key in fields if document.get(key) is not None]
    if document["parse_status"] != "SUCCESS":
        header.append("注意：此文字需依解析狀態複核，不應直接視為完整且已驗證的內容。")
    path = directory / (document["document_id"] + "_" + safe_filename(document["title"]) + ".txt")
    path.write_text("\n".join(header) + "\n\n===== 正文 =====\n\n" + body + "\n", encoding="utf-8")
    document["processed_file"] = path.as_posix()


def run_documents(sources, offline=False, refresh_raw=False, raw_dir="data/raw", processed_dir="data/processed"):
    """main 呼叫；inventory→raw＋TXT＋metadata＋來源映射與摘要。每個 Document 錯誤隔離。"""
    directory = Path(processed_dir)
    directory.mkdir(parents=True, exist_ok=True)
    previous_path = directory / "metadata.json"
    previous = json.loads(previous_path.read_text(encoding="utf-8")) if previous_path.exists() else []
    raw = RawStore(raw_dir, offline=offline, refresh=refresh_raw)
    plans = group_sources(sources)
    documents = [p["document"] for p in plans]
    started_at = datetime.now(timezone.utc).isoformat()
    try:
        for number, plan in enumerate(plans, 1):
            doc, source = plan["document"], plan["primary"]
            text = ""
            print(f"[Document {number}/{len(plans)}] {doc['document_type']} {doc['title']}", flush=True)
            def keep(item):
                if item["path"] not in doc["raw_files"]:
                    doc["raw_files"].append(item["path"])
                    doc["raw_source_ids"].append(item["source_id"])
                return Path(item["path"]).read_bytes()
            try:
                if doc["document_type"] == "regulation":
                    basic = keep(raw.html(plan["basic"])) if plan["basic"] else None
                    if not plan["complete"]:
                        raise ValueError("inventory 沒有已確認的所有條文頁，未把個別條文假裝完整正文。")
                    full = keep(raw.html(plan["complete"]))
                    result = parse_regulation(full, basic)
                elif doc["document_type"] == "announcement":
                    result = parse_announcement(keep(raw.html(source)))
                else:
                    item = raw.attachment(source)
                    # 不把完整 PDF 再讀進記憶體，交由 parser 從 path 開啟。
                    doc["raw_files"].append(item["path"])
                    doc["raw_source_ids"].append(item["source_id"])
                    doc.update(file_type=item["file_type"], file_type_evidence=item["format_evidence"])
                    result = parse_attachment(item["path"], item["file_type"])
                doc.update(result["metadata"])
                doc["notes"].extend(result["notes"])
                doc["parse_status"] = result["parse_status"]
                text = result["text"]
            except RawUnavailable as exc:
                doc["parse_status"] = "DOWNLOAD_FAILED"
                doc["notes"].append(str(exc))
                if exc.raw_file:
                    doc["raw_files"].append(exc.raw_file)
            except Exception as exc:
                doc["parse_status"] = "PARSE_FAILED"
                doc["notes"].append(f"{type(exc).__name__}: {exc}")
            try:
                write_text_document(doc, text, directory)
            except Exception as exc:
                doc["parse_status"] = "PARSE_FAILED"
                doc["notes"].append(f"TXT output: {type(exc).__name__}: {exc}")
        mark_duplicates(documents)
    finally:
        raw.close()
    # parser 改變或某文件本輪失敗時，不讓上輪成功 TXT 被誤當這次成功輸出。
    # 只搬移前次 metadata 明列且位於 processed 根目錄的程式產物，不刪使用者檔案。
    active = {d["processed_file"] for d in documents if d["processed_file"]}
    for old in previous:
        if old.get("processed_file") and old["processed_file"] not in active:
            stale = Path(old["processed_file"])
            if stale.exists() and stale.resolve().parent == directory.resolve() and stale.name.startswith(old["document_id"] + "_"):
                archive = directory / "_previous"
                archive.mkdir(exist_ok=True)
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
                stale.replace(archive / (stamp + "_" + stale.name))
    mapping = []
    for source in sources:
        ids = [d["document_id"] for d in documents if source["id"] in d["source_ids"]]
        mapping.append({"source_id": source["id"], "source_url": source["source_url"], "source_type": source["source_type"], "source_status": source["crawl_status"], "document_ids": ids,
                        "reason": None if ids else "來源清單保留；非本階段內容來源或受阻，不重新請求。"})
    statuses = Counter(d["parse_status"] for d in documents)
    kinds = Counter(d["document_type"] for d in documents)
    used_raw = {p for d in documents for p in d["raw_files"]}
    raw_types = Counter(item["file_type"] for item in raw.manifest.values() if item["path"] in used_raw)
    summary = {"started_at": started_at, "finished_at": datetime.now(timezone.utc).isoformat(), "documents": len(documents), "document_types": dict(kinds), "parse_statuses": dict(statuses),
               "raw_files": dict(raw_types), "txt_files": sum(d["processed_file"] is not None for d in documents), "duplicates": sum(d["duplicate"] for d in documents),
               "pdf_with_text": sum(d.get("file_type") == "pdf" and bool(d.get("processed_file")) for d in documents),
               "pdf_success": sum(d.get("file_type") == "pdf" and d["parse_status"] == "SUCCESS" for d in documents),
               "requests_count": len(raw.client.events), "raw_cache_hits": raw.cache_hits,
               "skipped_sources": sum(not row["document_ids"] for row in mapping), "blocked_sources": [row for row in mapping if row["source_status"] == "robots_blocked"],
               "notes": ["EMPTY_CONTENT 等無可用正文的 Document 保留 metadata，processed_file=null；不輸出只有 header 的假正文 TXT。", "PDF 表格跨行/合併儲存格需複核；有 TXT 不等於 SUCCESS。", "raw HTML 可來自 Phase 2 evidence，保留當時快照；不是宣稱重新檢查現行法規。"]}
    outputs = [("metadata.json", documents), ("summary.json", summary), ("source_document_map.json", mapping), ("requests.json", raw.client.events)]
    for name, value in outputs:
        (directory / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n===== Phase 3 Document Summary =====")
    print("Documents：", len(documents))
    for kind in ["regulation", "announcement", "attachment"]:
        print(kind, "documents：", kinds[kind])
    print("Raw files：", dict(raw_types))
    for label, count in [("HTML raw files", raw_types["html"]), ("PDF raw files", raw_types["pdf"]), ("DOCX raw files", raw_types["docx"]), ("DOC raw files", raw_types["doc"]), ("Other raw files", sum(v for k, v in raw_types.items() if k not in {"html", "pdf", "doc", "docx"}))]:
        print(label + "：", count)
    for status in ["SUCCESS", "EMPTY_CONTENT", "OCR_REQUIRED", "CONVERSION_REQUIRED", "UNSUPPORTED", "TABLE_REVIEW_REQUIRED", "TEXT_REVIEW_REQUIRED", "DOWNLOAD_FAILED", "PARSE_FAILED"]:
        print(status + "：", statuses[status])
    print("Duplicates：", summary["duplicates"])
    print("TXT：", summary["txt_files"])
    return documents, summary
