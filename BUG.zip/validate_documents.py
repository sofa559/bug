"""離線核對 Phase 3 的 TXT、metadata、raw 和 Source 關係；不請求網站。"""

import json
import re
from pathlib import Path

import pymupdf
from bs4 import BeautifulSoup

from documents.cleaners import clean_text, content_hash
from documents.raw import file_hash
from inventory.urls import allowed


def validate(directory="data/processed", inventory_path="data/inventory/sources.json", raw_dir="data/raw"):
    """CLI 呼叫；input 為三個資料路徑→validation.json/md；任一結構檢查失敗則 exit 1。

    檢查 9 法規的完整所有條文、3 PDF 樣本、1 空公告及 OCR 樣本；
    抽取成功與內容品質分開，不把 TABLE_REVIEW_REQUIRED 當作驗證器故障。
    """
    root, raw_root = Path(directory), Path(raw_dir)
    docs = json.loads((root / "metadata.json").read_text(encoding="utf-8"))
    sources = json.loads(Path(inventory_path).read_text(encoding="utf-8"))
    manifest = json.loads((raw_root / "manifest.json").read_text(encoding="utf-8"))
    mapping = json.loads((root / "source_document_map.json").read_text(encoding="utf-8"))
    history = json.loads((raw_root / "requests_history.json").read_text(encoding="utf-8"))
    by_id, by_source = {d["document_id"]: d for d in docs}, {s["id"]: s for s in sources}
    checks, samples = [], []
    def check(name, condition):
        checks.append({"check": name, "passed": bool(condition)})
    def body(doc):
        if not doc["processed_file"]:
            return ""
        return Path(doc["processed_file"]).read_text(encoding="utf-8").split("===== 正文 =====\n", 1)[1].strip()
    required = {"document_id", "title", "document_type", "source_name", "source_ids", "source_urls", "primary_source_url", "categories", "parent_document_id", "parent_title", "published_date", "amended_date", "effective_date", "announcement_date", "raw_files", "processed_file", "parse_status", "duplicate", "duplicate_of", "content_hash", "notes"}
    check("每份 Document 包含必要欄位", all(required <= d.keys() for d in docs))
    check("Document ID 唯一", len(by_id) == len(docs))
    check("所有 Source ID 與 URL 可回到 inventory", all(sid in by_source and by_source[sid]["source_url"] in d["source_urls"] for d in docs for sid in d["source_ids"]))
    check("185 筆來源保留完整 Source→Document 映射", len(mapping) == len(sources) and {m["source_id"] for m in mapping} == set(by_source))
    check("映射反向對應一致", all(set(m["document_ids"]) == {d["document_id"] for d in docs if m["source_id"] in d["source_ids"]} for m in mapping))
    check("外站與受阻來源沒有 Document content", all(not m["document_ids"] for m in mapping if m["source_status"] in {"external_skipped", "robots_blocked"}))
    check("所有 Phase 3 請求仍在官方範圍", all(allowed(e["url"]) for e in history))
    blocked_urls = {s["source_url"] for s in sources if s["crawl_status"] == "robots_blocked"}
    check("沒有重新請求受阻舊來源", all(e["url"] not in blocked_urls and not e["url"].startswith("http://web.law.ntpc.gov.tw") for e in history))
    check("所有 raw 存在且 hash 等於保存紀錄", all(Path(i["path"]).exists() and file_hash(i["path"]) == i["raw_sha256"] for i in manifest.values()))
    check("所有文件使用的 raw 在 manifest", all(p in {i["path"] for i in manifest.values()} for d in docs for p in d["raw_files"]))
    files = [d["processed_file"] for d in docs if d["processed_file"]]
    check("TXT 檔名唯一，同名附表未覆蓋", len(files) == len(set(files)) and all(Path(p).exists() for p in files))
    check("processed 根目錄無未被 metadata 引用的舊 TXT", {p.resolve() for p in root.glob("*.txt")} == {Path(p).resolve() for p in files})
    check("TXT 皆有非空正文且 hash 正確", all(body(d) and content_hash(body(d)) == d["content_hash"] for d in docs if d["processed_file"]))
    check("空內容未生成假的 TXT/hash", all(d["processed_file"] is None and d["content_hash"] is None for d in docs if d["parse_status"] == "EMPTY_CONTENT"))
    check("所有 parent ID 存在且不指向自己", all(parent in by_id and parent != d["document_id"] for d in docs for parent in d["parent_document_ids"]))
    check("parent title 與母文件一致", all(d["parent_title"] == by_id[d["parent_document_id"]]["title"] for d in docs if d["parent_document_id"]))
    check("duplicate_of 對應相同非空正文 hash", all(d["duplicate_of"] in by_id and d["content_hash"] and by_id[d["duplicate_of"]]["content_hash"] == d["content_hash"] for d in docs if d["duplicate"]))
    laws = [d for d in docs if d["document_type"] == "regulation"]
    check("72 law_system_page 聚合成 9 regulation", len(laws) == 9 and sum(len(d["source_ids"]) for d in laws) == 72)
    for law in laws:
        full = next((manifest[sid] for sid in law["raw_source_ids"] if "FLAWDAT0202.aspx" in manifest[sid]["source_url"]), None)
        soup = BeautifulSoup(Path(full["path"]).read_bytes(), "html.parser") if full else None
        pre = soup.select(".content2 td.col-td pre") if soup else []
        text = body(law)
        expected = [clean_text(p.get_text()) for p in pre]
        positions = [text.find(paragraph) for paragraph in expected]
        check(f"{law['law_id']}：全部條文按原序保留", bool(expected) and all(pos >= 0 for pos in positions) and positions == sorted(positions) and len(pre) == len(law.get("article_numbers", [])))
        check(f"{law['law_id']}：標題正確且無 menu/footer", soup is not None and soup.select_one("#cph_content_lawheader_hlkLNNAME").get_text(" ", strip=True) == law["title"] and all(noise not in text for noise in ["瀏覽人數", "本網站為新北市政府版權所有", "跳至主要內容", "navbar"]))
        if law["law_id"] in {"C0040063", "C0040048", "C0040014"}:
            samples.append({"kind": "regulation", "document_id": law["document_id"], "title": law["title"], "article_count": len(pre), "published_date": law["published_date"], "amended_date": law["amended_date"], "effective_date": law["effective_date"], "finding": "對照完整 HTML；條文順序與全文保留，無導覽頁尾。"})
    for doc in docs:
        if doc["document_type"] == "attachment":
            source = by_source[doc["source_ids"][0]]
            known_urls = set(source.get("parent_urls", []) + source.get("regulation_urls", []))
            if doc["parent_document_id"]:
                check(f"{doc['document_id']}：附件母文件可追溯", bool(known_urls & set(by_id[doc["parent_document_id"]]["source_urls"])))
            else:
                check(f"{doc['document_id']}：無明確母文件時不猜", not known_urls and doc["parent_title"] is None)
    for key in ["att_9cb3ac8b94e65d1c", "att_a53b0ff97c2cb372", "att_73f462e17ea27fc2"]:
        doc = by_id[key]
        text = body(doc)
        check(f"{key}：PDF TXT 有繁體文字而非亂碼", bool(re.search(r"[\u4e00-\u9fff]", text)) and "\ufffd" not in text and len(text) > 100)
        with pymupdf.open(doc["raw_files"][0]) as pdf:
            check(f"{key}：PDF 頁數正確", len(pdf) == doc["page_count"])
        samples.append({"kind": "pdf", "document_id": key, "title": doc["title"], "parse_status": doc["parse_status"], "page_count": doc["page_count"], "finding": "已檢查文字層及來源；視覺對照另見 manual_review.json。"})
    announcement = next(d for d in docs if d["document_type"] == "announcement")
    soup = BeautifulSoup(Path(announcement["raw_files"][0]).read_bytes(), "html.parser")
    check("公告真正空正文保留 EMPTY_CONTENT", not soup.select_one(".worddisaplay").get_text(strip=True) and announcement["parse_status"] == "EMPTY_CONTENT" and announcement["processed_file"] is None)
    check("公告日期與生效日期分離", announcement["announcement_date"] == "2023-08-10" and announcement["effective_date"] == "2023-09-01" and announcement["published_date"] is None)
    check("空公告的兩個附件仍有母文件", sum(d["parent_document_id"] == announcement["document_id"] for d in docs) == 2)
    samples.append({"kind": "announcement", "document_id": announcement["document_id"], "finding": "正文空白不生成 TXT；兩個 PDF 仍連回母公告。"})
    scan = by_id["att_f9c837522a357774"]
    check("掃描 PDF 有 raw、無假正文 TXT", scan["parse_status"] == "OCR_REQUIRED" and scan["processed_file"] is None and Path(scan["raw_files"][0]).exists() and all(p["text_characters"] == 0 for p in scan["page_quality"]))
    samples.append({"kind": "scanned_pdf", "document_id": scan["document_id"], "finding": "兩頁皆零文字；影像仍保存，未 OCR。"})
    manual_path = root / "manual_review.json"
    if manual_path.exists():
        manual = json.loads(manual_path.read_text(encoding="utf-8"))
        check("人工視覺核對對應本次原始 PDF hash", all(file_hash(by_id[r["document_id"]]["raw_files"][0]) == r["raw_sha256"] for r in manual["pdf_samples"]))
    review = [{"document_id": d["document_id"], "status": d["parse_status"], "notes": d["notes"]} for d in docs if d["parse_status"] != "SUCCESS"]
    report = {"passed": all(c["passed"] for c in checks), "checks": checks, "samples": samples, "review_queue": review, "note": "通過表示清單與狀態如實，不表示 TABLE_REVIEW_REQUIRED/OCR_REQUIRED 已解決。"}
    (root / "validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = ["# Phase 3 驗證", "", report["note"], "", f"通過 {sum(c['passed'] for c in checks)} / {len(checks)} 項。", "", "## 結構與內容檢查", ""]
    lines += [f"- {'PASS' if c['passed'] else 'FAIL'}：{c['check']}" for c in checks]
    lines += ["", "## 抽查", "", "```json", json.dumps(samples, ensure_ascii=False, indent=2), "```", "", "## 待複核文件", "", "```json", json.dumps(review, ensure_ascii=False, indent=2), "```"]
    (root / "validation.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Phase 3 validation: {sum(c['passed'] for c in checks)}/{len(checks)} passed; samples={len(samples)}")
    if not report["passed"]:
        print([c for c in checks if not c["passed"]])
        raise SystemExit(1)
    return report


if __name__ == "__main__":
    validate()
