# Phase 2 執行報告

完成日期：2026-09-23。唯一 START_URL：<https://www.economic.ntpc.gov.tw/List/about-law>。

已實際執行來源探索、輸出 JSON/CSV 並抽查。**有 1 筆舊來源因 HTTP robots 無法取得而未深入，不能宣稱所有來源內容皆已確認。**沒有進入 Phase 3。

## A／B. 建立的檔案與職責

| 檔案 | 職責 |
|---|---|
| main.py | 啟動探索及保存結果 |
| inventory/__init__.py | Python 套件標記 |
| inventory/urls.py | 唯一起點、URL 正規化、官方網域與同法規範圍 |
| inventory/http_client.py | 延遲、timeout、retry、robots、redirect 防線、少量檔頭 |
| inventory/discovery.py | queue、HTML 探索、表單、URL 去重、多來源關係、統計 |
| inventory/output.py | JSON/CSV/摘要/請求紀錄輸出 |
| tests/test_inventory.py | 16 個離線測試 |
| validate_inventory.py | 對照實際 HTML，檢查 JSON/CSV 與抽查來源 |
| requirements.txt | requests、beautifulsoup4 依賴 |
| README.md | 每個檔案的 input/output、套件用途、重要函式、欄位、執行教學 |

詳細教學請讀 README。Phase 1 的 phase1_evidence 保留，並非正式程式的 URL 清單；正式探索沒有讀它當 seed。

## C. 套件與原因

- requests：向伺服器發送 GET/POST，接收 HTML、headers 及最多 512 bytes 的附件檔頭。
- BeautifulSoup：把 HTML 轉成可搜尋 DOM，針對內容區定位名稱、連結、表單，避免導覽和頁尾。
- urllib.parse：把相對 URL 補完整、拆解 URL；正規化時保留原 query percent bytes，避免破壞舊 Big5 連結。
- urllib.robotparser：解析有效 robots 規則。
- collections：deque 管待探索清單、Counter 做統計。
- hashlib：用 URL 產生穩定來源 ID，不是文件內容 hash。
- email.message：解碼 Content-Disposition 的 UTF-8 filename*。
- json/csv/pathlib：保存巢狀資料、人工清單及 HTML 證據。
- time/datetime/re：請求間隔、觀察時間、總筆數/格式辨識。
- unittest/mock/tempfile/io：離線測試與模擬 HTTP，避免用真實網站做錯誤測試。

## D. 資料流

START_URL → queue → HTTP 邊界檢查 → 實際 DOM 判型 → 列表下一頁/子分類/同法規頁/附件 → URL 去重並保留發現關係 → JSON/CSV。

外站在入 queue 前排除，redirect 每一跳也先檢查。所有條文 POST 的目的頁來自實際表單回應，不拼造頁數、分類 URL 或法規全文 URL。

## E. 實際來源數

| 統計 | 數量 |
|---|---:|
| 正規化並合併 redirect alias 後來源 | 185 |
| 主列表頁 | 4 |
| 子分類列表頁 | 7 |
| 重複 URL 再次發現次數 | 73 |
| 成功探索或附件檢查 | 96 |
| HTTP/解析 failed 來源 | 0 |
| 略過／受阻 | 89 |
| pending | 0 |

failed=0 **不代表沒有未完成來源**：89 筆略過/受阻中包含 1 筆 robots_blocked。

## F. 五個子分類

| 分類 | 列表頁數 | 發現列表條目 | 與網站總筆數一致 |
|---|---:|---:|---|
| 公司登記 | 1 | 5 | 是 |
| 商業登記 | 1 | 4 | 是 |
| 工廠登記 | 3 | 22 | 是 |
| 電器承裝業登記 | 1 | 5 | 是 |
| 動產擔保登記 | 1 | 2 | 是 |

共 38 個子分類列表條目。這是入口數，不是已下載法規數；多數為外站。主列表 34 個入口也與網站一致。

## G. source_type 數量

| source_type | 數量 |
|---|---:|
| category_page | 11 |
| regulation_page | 0 |
| law_system_page | 72 |
| announcement_page | 1 |
| direct_attachment | 12 |
| external_skipped | 52 |
| portal_skipped | 1 |
| related_page_skipped | 34 |
| search_skipped | 1 |
| unknown | 1 |

72 個法規系統 URL 是 9 份法規的 9 個基本資料頁、9 個所有條文頁、54 個個別條文頁，不是 72 份不同法規。

新增的三種類型，是為了將「整站入口」「相關/歷史法條等延伸頁」「搜尋入口」與真正無法辨識的 unknown 分開；這三種全部只記錄、不深入。

## H. 附件格式

12 個不同附件 URL，全數確認 PDF magic `%PDF-`，每個只讀 512 bytes。未保存完整 PDF。

本次允許探索的來源內未發現 DOC、DOCX、XLS、XLSX、ODT、ZIP。外站及受阻舊來源中的格式目前無法確認。

附件 Content-Type 有 application/unknown 和 application/octet-stream，因此同時保存 filename、Content-Disposition 與 format_evidence。

## I. unknown / failed / skipped

唯一 unknown：

- 名稱：新北市政府辦理非都市土地丁種建築用地容許作工業設施使用之低污染事業認定作業要點。
- 來源：工廠登記第 2 頁。
- URL：<http://web.law.ntpc.gov.tw/Scripts/Newsdetail.asp?NO=1C0040004>
- 狀態：robots_blocked。
- 原因：HTTP origin 的 robots.txt 兩次連線均遭 WinError 10061 拒絕，程式保守停止該 origin；**不是已讀到 Disallow，也沒有取得該法規頁的 HTTP 回應。**
- 現行有效網址及內容目前無法確認，沒有猜測換新 URL。

另外「都市計畫法新北市施行細則」指向 Query4B.asp 舊式搜尋入口，依明確排除搜尋結果的要求標記 search_skipped。其原始 Big5 percent 參數已完整保存。

其餘略過：52 外站、34 相關/歷史/訴願等延伸頁、1 法規總入口。這些是範圍控制，不是抓取錯誤。

## J. 輸出位置與驗證

資料夾：`data/inventory/`

- sources.json：pipeline 用的 185 筆紀錄。
- sources.csv：同樣 185 筆，UTF-8 BOM。
- summary.json：分類完整性、類型、狀態及表單統計。
- requests.json：122 次請求紀錄，包含 robots、redirect、POST、retry 與 5 個附件的少量檔頭複查。
- evidence/*.html：已取得頁面的 HTML，供離線對照。
- validation.json / validation.md：27 項檢查通過、12 筆抽查。

抽查內容：

- 五個子分類各 1 筆一般來源，共 5 筆；與經發局列表的顯示名稱、href、分類比對。外部目標本身不請求。
- 3 筆新北市法規入口，核對來源列表、名稱、URL 與類型。
- 3 筆附件，分別涵蓋經發局下載、法規公告下載、法規附件下載；核對父頁和 headers/檔頭紀錄。
- 1 筆 external_skipped，確認有來源關係且請求紀錄沒有外站。
- JSON/CSV 一致、五分類總筆數、所有引用可回連、無 pending、沒有舊編碼 replacement character 等檢查皆通過。

## K. Phase 3 前的風險

1. 1 筆舊來源受阻，現行有效網址與內容需要另行確認。
2. 全國法規資料庫及其他外站只有來源 metadata，不含正文與附件。
3. 這階段沒驗證 PDF 是否掃描、文字是否可抽、檔案是否完整。
4. 公告版本、修法日期與現行有效條文不能單憑 URL 判定。
5. 多個附件都叫「附表.PDF」，之後不能只靠檔名存檔；應使用來源 ID 避免覆蓋。
6. 72 個法規頁 URL 不應各自不加區分地當成 72 份法規交給 RAG；後續需要沿來源關係選擇全文與附件，避免重複。

**停在 Phase 2。**
