"""從唯一 START_URL 建立有邊界的來源圖；只發現與檢查，不解析或保存完整附件。"""

import hashlib
import re
from collections import Counter, deque
from datetime import datetime, timezone
from email.message import Message
from pathlib import Path
from urllib.parse import parse_qsl, unquote, urlsplit

from bs4 import BeautifulSoup

from inventory.http_client import HttpClient
from inventory.urls import ECONOMIC_HOSTS, LAW_HOST, START_URL, allowed, attachment_hint, classify_url, law_identity, normalize_url


def clean(node):
    """parser 共用：input DOM 元素，output 去頭尾空白的顯示文字或 None。"""
    return node.get_text(" ", strip=True) or None if node else None


def append_unique(items, value):
    if value is not None and value not in items:
        items.append(value)


def clean_parent_relationships(records):
    """results 呼叫：將條文頁返回基本資料的導覽連結保留為發現關係，移除反向父子關係。

    input/output 是同一批 Record（原地更新）；否則基本資料→全文→基本資料會
    形成不合理的 parent cycle。discovered_from/discovery_edges 仍保存真實連結。
    """
    for record in records:
        if urlsplit(record["source_url"]).path.lower() == "/scripts/flawdat01.aspx":
            for edge in record["discovery_edges"]:
                if edge["relation"] == "same_law_link":
                    edge["parent_url"] = None
            record["parent_urls"] = list(dict.fromkeys(e["parent_url"] for e in record["discovery_edges"] if e["parent_url"]))
        record["parent_url"] = next(iter(record["parent_urls"]), None)


class Discovery:
    """以 queue 串行探索。records 管每個來源，discovery_edges 管來源間的關係。"""

    def __init__(self, client=None, evidence_dir=None):
        self.client = client or HttpClient()
        self.records = {}
        self.aliases = {}
        self.queue = deque()
        self.cache = {}
        self.duplicate_count = 0
        self.interrupted = False
        self.started_at = datetime.now(timezone.utc).isoformat()
        self.list_pages = []
        self.operations = []
        self.evidence_dir = Path(evidence_dir) if evidence_dir else None

    def canonical(self, url):
        seen = set()
        while url in self.aliases and url not in seen:
            seen.add(url)
            url = self.aliases[url]
        return url

    def note(self, record, text):
        if text and text not in (record["notes"] or []):
            record["notes"] = (record["notes"] or []) + [text]

    def add_source(self, url, title=None, categories=(), found_from=None, parent=None, regulation=None, relation="link", scope=None):
        """列表/詳細頁 parser 呼叫；input 為 URL 與來源關係，output 為共用 Source Record。

        同 URL 不重建資料，也不丟掉第二條發現路徑。scope 僅限制法規代碼，
        並不產生新 URL。只有官方個別来源才排進 queue。
        """
        original = normalize_url(found_from or START_URL, url)
        if not original:
            return None
        key = self.canonical(original)
        if key in self.records:
            record = self.records[key]
            self.duplicate_count += 1
        else:
            kind = classify_url(key)
            status = "external_skipped" if kind == "external_skipped" else "skipped_scope" if kind in {"portal_skipped", "related_page_skipped", "search_skipped"} else "pending"
            record = {
                "id": "src_" + hashlib.sha256(key.encode()).hexdigest()[:20],
                "title": title, "category": next(iter(categories), None), "categories": list(categories),
                "source_type": kind, "source_url": key, "original_urls": [original],
                "parent_url": parent, "parent_urls": [parent] if parent else [],
                "regulation_urls": [regulation] if regulation else [],
                "discovered_from": [], "discovery_edges": [], "observed_titles": [],
                "domain": urlsplit(key).hostname, "crawl_status": status, "notes": None,
                "http_status": None, "redirect_chain": [], "content_type": None,
                "content_disposition": None, "response_encoding": None,
                "attachment_url": key if kind == "direct_attachment" else None,
                "filename": None, "file_type": None, "format_evidence": None,
                "future_handling": None, "bytes_inspected": None,
                "scope_law_id": scope or law_identity(key),
                "observed_at": self.started_at,
                "evidence_html": None,
            }
            self.records[key] = record
            if status == "pending":
                self.queue.append(key)
            elif kind == "portal_skipped":
                self.note(record, "整站法規資料庫入口；非個別法規，依 bounded crawl 範圍只記錄。")
            elif kind == "related_page_skipped":
                self.note(record, "相關法條、歷史法條、函釋或訴願等延伸頁；非本階段條文/附件，僅記錄。")
            elif kind == "search_skipped":
                self.note(record, "舊式法規查詢頁；依使用者要求不抓搜尋結果，只保留原始查詢 URL。")
        for category in categories:
            append_unique(record["categories"], category)
        append_unique(record["original_urls"], original)
        append_unique(record["observed_titles"], title)
        append_unique(record["discovered_from"], found_from)
        append_unique(record["parent_urls"], parent)
        append_unique(record["regulation_urls"], regulation)
        if not record["title"]:
            record["title"] = title
        if found_from:
            edge = {"from_url": found_from, "parent_url": parent, "category": next(iter(categories), None), "relation": relation, "link_text": title, "original_url": original}
            append_unique(record["discovery_edges"], edge)
        if record["source_type"] == "direct_attachment":
            self.attachment_metadata(record, {})
        return record

    def redirect_guard(self, record):
        """HTTP 層呼叫回傳的 predicate：redirect 也必須留在同法規或經發局來源路徑內。"""
        scope = record["scope_law_id"]
        def guard(url):
            kind = classify_url(url)
            host = urlsplit(url).hostname
            if not allowed(url):
                return False
            if host == LAW_HOST:
                if kind == "direct_attachment":
                    return True
                if kind == "law_system_page":
                    return bool(law_identity(url)) and (not scope or law_identity(url) == scope)
                if kind == "announcement_page":
                    return record["source_type"] in {"announcement_page", "category_page", "unknown"}
                if urlsplit(url).path.lower() == "/scripts/newsdetail.asp":
                    return bool(scope) and law_identity(url) == scope
                return False
            return kind != "portal_skipped" and host in ECONOMIC_HOSTS
        return guard

    def resolve_redirect(self, record, result):
        """run 呼叫：以實際 final URL 合併紀錄，保留入口 alias 及全部來源邊。"""
        final = normalize_url(record["source_url"], result["url"])
        old = record["source_url"]
        record["redirect_chain"] = result.get("redirects", [])
        if final == old:
            return record
        self.aliases[old] = final
        if final in self.records:
            target = self.records[final]
            for field in ["original_urls", "categories", "discovered_from", "parent_urls", "regulation_urls", "discovery_edges", "observed_titles", "redirect_chain"]:
                for value in record[field]:
                    append_unique(target[field], value)
            self.records.pop(old, None)
            return target
        self.records.pop(old)
        record.update(source_url=final, id="src_" + hashlib.sha256(final.encode()).hexdigest()[:20], domain=urlsplit(final).hostname)
        record["source_type"] = classify_url(final)
        record["scope_law_id"] = record["scope_law_id"] or law_identity(final)
        if record["source_type"] == "direct_attachment":
            record["attachment_url"] = final
        self.records[final] = record
        return record

    def run(self):
        """main 呼叫；從 START_URL 開始，queue 耗盡即停止，每個錯誤只影響該來源。"""
        self.add_source(START_URL, relation="start")
        processed = 0
        while self.queue:
            url = self.canonical(self.queue.popleft())
            record = self.records[url]
            if record["crawl_status"] != "pending":
                continue
            processed += 1
            print(f"[{processed}] {record['source_type']} {url}", flush=True)
            try:
                result = self.cache.pop(url, None) or self.client.fetch(url, guard=self.redirect_guard(record), attachment=record["source_type"] == "direct_attachment")
                if result["status"] in {"external_redirect", "scope_redirect"}:
                    target = self.add_source(result["url"], record["title"], record["categories"], url, relation="redirect_target")
                    if target and result["status"] == "scope_redirect":
                        target["crawl_status"] = "skipped_scope"
                        self.note(target, "轉址目的地不屬於這筆法規允許探索的範圍。")
                    record.update(crawl_status="skipped_scope", redirect_chain=result.get("redirects", []))
                    self.note(record, "已記錄轉址目的地，未向範圍外目的地發送請求。")
                    continue
                record["http_status"] = result.get("http_status")
                if result["status"] != "ok":
                    record["crawl_status"] = result["status"]
                    self.note(record, result.get("error") or f"HTTP {result.get('http_status')}; {result['status']}")
                    continue
                record = self.resolve_redirect(record, result)
                if record["crawl_status"] != "pending":
                    continue
                headers = result.get("headers", {})
                record.update(http_status=result.get("http_status"), content_type=headers.get("content-type"), content_disposition=headers.get("content-disposition"), response_encoding=result.get("encoding"))
                if not result.get("is_html"):
                    self.attachment_metadata(record, result)
                    if record["source_type"] == "direct_attachment" or record["filename"] or result.get("body", b"").startswith(b"%PDF-"):
                        record.update(source_type="direct_attachment", attachment_url=record["source_url"], crawl_status="success")
                    else:
                        record.update(source_type="unknown", crawl_status="unexpected_content")
                        self.note(record, "回應不是可辨認的 HTML，也無法確認為附件。")
                    continue
                soup = BeautifulSoup(result["body"], "html.parser")
                if self.evidence_dir:
                    self.evidence_dir.mkdir(parents=True, exist_ok=True)
                    path = self.evidence_dir / (record["id"] + ".html")
                    path.write_bytes(result["body"])
                    record["evidence_html"] = path.as_posix()
                if soup.html is None or soup.body is None:
                    record.update(crawl_status="invalid_html", source_type="unknown")
                    continue
                record["crawl_status"] = "success"
                self.parse_html(record, soup)
            except Exception as exc:
                record["crawl_status"] = "parse_error"
                self.note(record, f"{type(exc).__name__}: {exc}")

    def parse_html(self, record, soup):
        """run 呼叫；根據真正 DOM 選擇 parser，不因 URL 看起來正確就判定成功。"""
        url = record["source_url"]
        title = clean(soup.title) or ""
        if any(word in title for word in ["頁面未找到", "權限不足", "404", "403", "Access Denied"]):
            record["crawl_status"] = "error_page"
            self.note(record, f"HTTP 成功但內容為錯誤頁：{title}")
            return
        if urlsplit(url).hostname in ECONOMIC_HOSTS:
            items = soup.select("main#main .item > a")
            if items and all(a.select_one(".font") for a in items):
                self.parse_list(record, soup, items)
                return
            # 若未來出現語意明確的 article，才接受為站內法規內容；不猜 CSS 類別。
            article = soup.select_one("main#main article")
            if article and article.select_one("h1, h2"):
                record.update(source_type="regulation_page", title=clean(article.select_one("h1, h2")))
                self.parse_attachments(record, article)
                return
        elif soup.select_one(".c-law table.tab-edit"):
            self.parse_law(record, soup)
            return
        elif soup.select_one("#cph_content_lawheader_hlkLNNAME") and soup.select_one(".content2 pre"):
            self.parse_law(record, soup)
            return
        elif soup.select_one(".content .edit-title .lawname"):
            record.update(source_type="announcement_page", title=clean(soup.select_one(".content .edit-title .lawname")))
            self.parse_attachments(record, soup.select_one(".content"))
            return
        record.update(source_type="unknown", crawl_status="unknown_page_type")
        self.note(record, "未辨識到已確認的內容結構；沒有抓取選單、footer 或猜測子連結。")

    def parse_list(self, record, soup, items):
        """parse_html 呼叫；讀內容區 items、分類標題和真正的下一頁，不寫死分類 URL。"""
        url = record["source_url"]
        heading = clean(soup.select_one("main#main h2.main-title"))
        category = heading or record["category"]
        record.update(source_type="category_page", title=heading or record["title"], category=category, categories=[category] if category else [])
        entries = []
        for a in items:
            target = normalize_url(url, a.get("href"))
            if not target:
                self.note(record, "列表含無法正規化的 href。")
                continue
            source = self.add_source(target, clean(a.select_one(".font")), record["categories"], url, relation="list_item")
            entries.append(source["source_url"])
        next_link = soup.select_one('.pagination-container a[rel="next"]')
        if next_link:
            next_url = normalize_url(url, next_link.get("href"))
            if next_url:
                child = self.add_source(next_url, heading, record["categories"], url, relation="pagination_next")
                if urlsplit(next_url).hostname != urlsplit(url).hostname or urlsplit(next_url).path != urlsplit(url).path:
                    child["crawl_status"] = "skipped_scope" if allowed(next_url) else "external_skipped"
                    self.note(child, "下一頁連結改變了列表路徑，停止自動深入。")
        total = re.search(r"總筆數\s*[:：]\s*(\d+)", clean(soup.select_one("main#main")) or "")
        self.list_pages.append({"url": url, "category": category, "is_main": urlsplit(url).path == urlsplit(START_URL).path, "reported_total": int(total.group(1)) if total else None, "entries": entries, "next_url": normalize_url(url, next_link.get("href")) if next_link else None})

    def parse_law(self, record, soup):
        """parse_html 呼叫；同一法規的基本資料、所有條文、個別條文與附件才繼續。

        表單只提交 HTML 中確實存在的「所有條文」，不按搜尋、歷史法規或相關法條。
        input 是來源與 DOM；output 是新增 queue 紀錄及來源關係，不輸出條文 TXT。
        """
        url = record["source_url"]
        scope = record["scope_law_id"] or law_identity(url)
        record.update(source_type="law_system_page", scope_law_id=scope)
        heading = soup.select_one("#cph_content_lawheader_hlkLNNAME") or soup.select_one(".c-law table.tab-edit tr:first-child td .lawname")
        record["title"] = clean(heading) or record["title"]
        content = soup.select_one(".content2")
        self.parse_attachments(record, content)
        for a in content.select("a[href]"):
            target = normalize_url(url, a["href"])
            if not target or attachment_hint(target):
                continue
            if not allowed(target):
                self.add_source(target, clean(a), record["categories"], url, parent=url, relation="external_content_link")
            elif classify_url(target) == "law_system_page" and scope and law_identity(target) == scope:
                self.add_source(target, clean(a), record["categories"], url, parent=url, regulation=(record["regulation_urls"] or [url])[0], relation="same_law_link", scope=scope)
            else:
                # 相關法條等內容連結可記錄，卻不跨法規擴散。
                other = self.add_source(target, clean(a), record["categories"], url, parent=url, relation="out_of_scope_content_link")
                if other and other["crawl_status"] == "pending":
                    other["crawl_status"] = "skipped_scope"
                    self.note(other, "不是這份法規的基本資料、所有條文、個別條文或附件；僅記錄。")
        button = soup.select_one('#cph_content_B5')
        if button and button.get("value") == "所有條文":
            form = button.find_parent("form")
            action = normalize_url(url, form.get("action") or url) if form else None
            if not action or not scope or law_identity(action) != scope or form.get("method", "get").lower() != "post":
                self.note(record, "所有條文表單結構與已驗證流程不同，目前無法確認提交方式。")
                record["crawl_status"] = "partial_failed"
                return
            data = {node["name"]: node.get("value", "") for node in form.select('input[type="hidden"][name]')}
            data[button["name"]] = button["value"]
            result = self.client.fetch(action, data=data, guard=self.redirect_guard(record))
            self.operations.append({"source_url": url, "operation": "all_articles_form", "status": result["status"], "final_url": result["url"], "http_status": result.get("http_status")})
            if result["status"] == "ok" and result.get("is_html") and result["url"] != url:
                child = self.add_source(result["url"], record["title"], record["categories"], url, parent=url, regulation=(record["regulation_urls"] or [url])[0], relation="all_articles_form", scope=scope)
                if child["crawl_status"] == "pending":
                    self.cache[child["source_url"]] = result
            else:
                record["crawl_status"] = "partial_failed"
                self.note(record, f"所有條文表單未成功取得另一個條文頁：{result['status']}；{result.get('http_status')}；{result['url']}")

    def parse_attachments(self, record, container):
        """內容 parser 呼叫；只看法規內容中的下載連結，排除頁首操作手冊等全站附件。"""
        if not container:
            return
        for a in container.select("a[href]"):
            target = normalize_url(record["source_url"], a["href"])
            if not target:
                continue
            in_file_zone = a.find_parent(class_="fileZone") is not None
            if attachment_hint(target) or in_file_zone:
                child = self.add_source(target, clean(a), record["categories"], record["source_url"], parent=record["source_url"], regulation=(record["regulation_urls"] or [record["source_url"]])[0], relation="attachment")
                if child and allowed(target):
                    child.update(source_type="direct_attachment", attachment_url=target)
                    self.attachment_metadata(child, {})

    def attachment_metadata(self, record, result):
        """附件候選/回應處理呼叫；從檔名、headers、小量 magic bytes 記錄格式及證據。

        只標記未来處理需求。ZIP 檔頭本身不能證明 DOCX；OLE 檔頭也不能單獨證明 DOC。
        """
        # 同附件稍後又從個別條文被發現時，不能用單純檔名線索覆蓋已驗證的檔頭。
        if not result and record["bytes_inspected"] is not None:
            return
        headers = result.get("headers", {})
        disposition = headers.get("content-disposition", "")
        filename = None
        if disposition:
            message = Message()
            message["Content-Disposition"] = disposition
            filename = message.get_filename()
        q = dict(parse_qsl(urlsplit(record["source_url"]).query))
        filename = filename or q.get("fileName") or q.get("filename") or q.get("file")
        if not filename:
            name = unquote(urlsplit(record["source_url"]).path.rsplit("/", 1)[-1])
            filename = name if re.search(r"\.[A-Za-z0-9]{1,5}$", name) and not name.lower().endswith((".aspx", ".ashx", ".asp")) else None
        if not filename and record["title"] and re.search(r"\.[A-Za-z0-9]{1,5}$", record["title"]):
            filename = record["title"]
        ext = filename.rsplit(".", 1)[-1].lower() if filename and "." in filename else None
        body = result.get("body", b"")
        evidence = []
        if ext:
            evidence.append("filename_extension")
        ct = headers.get("content-type", "").split(";", 1)[0].lower()
        mime_types = {"application/pdf": "pdf", "application/msword": "doc", "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx", "application/vnd.ms-excel": "xls", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx", "application/vnd.oasis.opendocument.text": "odt", "application/zip": "zip"}
        fmt = ext or mime_types.get(ct)
        if ct in mime_types:
            evidence.append("content_type")
        if body.startswith(b"%PDF-"):
            if fmt and fmt != "pdf":
                self.note(record, "副檔名/MIME 與 PDF magic bytes 不一致，以檔頭標記 PDF。")
            fmt = "pdf"
            evidence.append("magic:%PDF-")
        elif body.startswith(b"PK\x03\x04"):
            evidence.append("magic:ZIP_container; subtype_not_verified")
            # DOCX/XLSX 是 ZIP 容器，但 subtype 必須由檔名/MIME 提供線索。
            if not fmt:
                self.note(record, "只確認 ZIP 容器，內部文件格式目前無法確認。")
        elif body.startswith(bytes.fromhex("d0cf11e0a1b11ae1")):
            evidence.append("magic:OLE_container; subtype_not_verified")
        record.update(filename=filename or None, file_type=fmt, format_evidence=evidence or None)
        if body:
            record["bytes_inspected"] = len(body)
        record["future_handling"] = "PARSE_LATER" if fmt in {"pdf", "docx"} else "CONVERSION_REQUIRED" if fmt == "doc" else "UNSUPPORTED" if fmt else None

    def results(self):
        """main 最後呼叫；修正 redirect 引用、傳播重複來源分類、計算統計，回傳 records/summary。"""
        clean_parent_relationships(self.records.values())
        for record in self.records.values():
            for field in ["parent_urls", "regulation_urls", "discovered_from"]:
                record[field] = list(dict.fromkeys(self.canonical(u) for u in record[field] if self.canonical(u) != record["source_url"]))
            for edge in record["discovery_edges"]:
                edge["from_url"] = self.canonical(edge["from_url"])
                if edge["parent_url"]:
                    edge["parent_url"] = self.canonical(edge["parent_url"])
        # 重複 URL 在已處理後才從另一分類被找到，其條文、附件仍需繼承新增分類。
        changed = True
        while changed:
            changed = False
            for record in self.records.values():
                if record["source_type"] == "category_page":
                    continue
                for edge in record["discovery_edges"]:
                    parent = self.records.get(edge["from_url"])
                    if parent:
                        for category in parent["categories"]:
                            if category not in record["categories"]:
                                record["categories"].append(category)
                                changed = True
        for record in self.records.values():
            record["category"] = next(iter(record["categories"]), None)
            record["parent_url"] = next(iter(record["parent_urls"]), None)
            if record["crawl_status"] == "pending" and self.interrupted:
                self.note(record, "本次執行被中止，尚未探索。")
        records = sorted(self.records.values(), key=lambda r: r["source_url"])
        types = Counter(r["source_type"] for r in records)
        statuses = Counter(r["crawl_status"] for r in records)
        skipped = {"external_skipped", "skipped_scope", "skipped_rate_limit", "robots_blocked"}
        groups = {}
        for page in self.list_pages:
            group = groups.setdefault(page["category"], {"reported_total": page["reported_total"], "pages": [], "entries": [], "is_main": page["is_main"]})
            group["pages"].append(page["url"])
            group["entries"].extend(self.canonical(u) for u in page["entries"])
        for group in groups.values():
            group["list_item_occurrences"] = len(group["entries"])
            group["unique_entry_count"] = len(set(group["entries"]))
            group["matches_reported_total"] = group["reported_total"] == group["list_item_occurrences"]
        failed = [r for r in records if r["crawl_status"] not in skipped | {"success", "pending"}]
        summary = {
            "start_url": START_URL, "started_at": self.started_at, "finished_at": datetime.now(timezone.utc).isoformat(), "interrupted": self.interrupted,
            "total_urls": len(records), "main_list_pages": sum(p["is_main"] for p in self.list_pages), "subcategory_pages": sum(not p["is_main"] for p in self.list_pages),
            "regulation_pages": types["regulation_page"], "law_system_pages": types["law_system_page"], "announcement_pages": types["announcement_page"], "attachments": types["direct_attachment"],
            "external_skipped": types["external_skipped"], "unknown": types["unknown"], "duplicate_urls": self.duplicate_count,
            "success": statuses["success"], "failed": len(failed), "skipped": sum(statuses[s] for s in skipped), "pending": statuses["pending"],
            "source_types": dict(types), "crawl_statuses": dict(statuses), "attachment_formats": dict(Counter(r["file_type"] or "unknown" for r in records if r["source_type"] == "direct_attachment")),
            "categories": groups, "robots": self.client.robots_notes, "requests_count": len(self.client.events), "form_operations": self.operations,
            "failures": [{"url": r["source_url"], "status": r["crawl_status"], "notes": r["notes"]} for r in failed],
            "counting_notes": "URL 層級去重，基本資料/全文/個別條文分別計數；不是獨立法規份數。重複 URL 是再次發現次數；類型包含僅記錄而未抓取的來源。",
        }
        return records, summary
