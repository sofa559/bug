"""把探索紀錄轉為 pipeline 可讀 JSON 與人工可讀 UTF-8 BOM CSV。"""

import csv
import json
from pathlib import Path


def save_inventory(records, summary, events, directory="data/inventory"):
    """main 呼叫；input 是來源、摘要、請求紀錄；output 是磁碟檔案與終端摘要。

    list/dict 欄位在 CSV 中以 JSON 文字保存，不拆掉多個分類與父子關係。
    JSON 缺值為 null；CSV 缺值為空白。CSV 不是附件下載清單的執行器。
    """
    p = Path(directory)
    p.mkdir(parents=True, exist_ok=True)
    for name, value in [("sources.json", records), ("summary.json", summary), ("requests.json", events)]:
        (p / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    if records:
        with (p / "sources.csv").open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(records[0]))
            writer.writeheader()
            for record in records:
                writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v for k, v in record.items()})
    print("\n===== Source Inventory Summary =====")
    labels = {"total_urls": "總共發現 URL", "main_list_pages": "主列表頁", "subcategory_pages": "子分類頁", "regulation_pages": "法規頁", "law_system_pages": "新北市法規系統", "announcement_pages": "公告頁", "attachments": "附件", "external_skipped": "外部連結 skipped", "unknown": "unknown", "duplicate_urls": "重複 URL（再次發現次數）", "success": "成功", "failed": "失敗", "skipped": "略過", "pending": "尚未完成"}
    for key, label in labels.items():
        print(f"{label}：{summary[key]}")
    print("source_type：", summary["source_types"])
    print("附件格式：", summary["attachment_formats"])
    print("輸出位置：", p.resolve())
