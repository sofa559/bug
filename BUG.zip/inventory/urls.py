"""集中處理網址與範圍，讓探索器及 HTTP 層使用同一套規則。"""

import html
import re
from urllib.parse import parse_qsl, quote, urljoin, urlsplit, urlunsplit

START_URL = "https://www.economic.ntpc.gov.tw/List/about-law"
ECONOMIC_HOSTS = {"economic.ntpc.gov.tw", "www.economic.ntpc.gov.tw"}
LAW_HOST = "web.law.ntpc.gov.tw"
ALLOWED_HOSTS = ECONOMIC_HOSTS | {LAW_HOST}
FILE_EXTENSIONS = {"pdf", "doc", "docx", "xls", "xlsx", "odt", "ods", "zip", "rar", "7z", "rtf", "txt", "csv", "ppt", "pptx", "jpg", "jpeg", "png", "tif", "tiff"}


def normalize_url(base, href):
    """探索器呼叫：相對連結→絕對網址，移除 fragment、排序 query 以便去重。

    input 是所在頁 URL 與 href；output 為 HTTP(S) URL 或 None。
    保留所有 query 名稱、值、重複值與空值，不猜測哪些參數可以刪除。
    """
    if not href or href.strip().startswith("#"):
        return None
    try:
        p = urlsplit(urljoin(base, html.unescape(href.strip())))
        if p.scheme.lower() not in {"http", "https"} or not p.hostname or p.username or p.password:
            return None
        port = p.port
        host = p.hostname.lower()
        netloc = host if port in (None, 443 if p.scheme.lower() == "https" else 80) else f"{host}:{port}"
        # 不先 decode 再 encode query：舊 ASP 連結含 Big5 percent bytes，UTF-8
        # parse_qsl 會用 U+FFFD 取代無法解碼的 bytes，永久改壞原始查詢條件。
        query = "&".join(sorted(quote(part, safe="%=:;/?,@!$'()*+-._~") for part in p.query.split("&")))
        return urlunsplit((p.scheme.lower(), netloc, quote(p.path or "/", safe="/%:@!$&'()*+,;=-._~"), query, ""))
    except (ValueError, TypeError):
        return None


def allowed(url):
    """HTTP 層與探索器共用：精確比對官方 hostname，不允許相似名稱網域或非標準 port。"""
    p = urlsplit(url)
    return p.hostname in ALLOWED_HOSTS and p.port in (None, 80, 443)


def law_identity(url):
    """由現有 URL 讀取法規代碼，只用於限制探索範圍，不用來拼造新網址。"""
    p = urlsplit(url)
    if p.hostname != LAW_HOST:
        return None
    q = {k.lower(): v for k, v in parse_qsl(p.query)}
    if "fcode" in q:
        return q["fcode"].upper()
    code = (q.get("lncode") or (q.get("no") if p.path.lower().endswith("/newsdetail.asp") else "") or "").upper()
    # Phase 1 實際對應：lncode=1C0040063 / fcode=C0040063。
    return code[1:] if re.fullmatch(r"1C\d+", code) else code or None


def attachment_hint(url):
    """根據實際連結端點或副檔名找附件候選；候選格式仍須由回應確認。"""
    p = urlsplit(url)
    path = p.path.lower()
    if path.endswith(("/download.ashx", "/downloadnews.ashx", "/api/upload/download")):
        return True
    return path.rsplit(".", 1)[-1] in FILE_EXTENSIONS


def classify_url(url):
    """add_source 呼叫的初步分類；取得 HTML 後會重新確認，不把 pattern 當成成功證明。"""
    p = urlsplit(url)
    path = p.path.lower()
    if not allowed(url):
        return "external_skipped"
    if attachment_hint(url):
        return "direct_attachment"
    if p.hostname in ECONOMIC_HOSTS:
        if path.startswith("/list/") or path == "/api/link/index":
            return "category_page"
        return "unknown"
    if path in {"/scripts/flawdat01.aspx", "/scripts/flawdat0202.aspx", "/scripts/flawdoc01.aspx"}:
        return "law_system_page"
    if path == "/news.aspx":
        return "announcement_page"
    if path == "/scripts/flawdoc02.aspx":
        return "related_page_skipped"
    if path == "/scripts/query4b.asp":
        return "search_skipped"
    if path in {"/", "/index.aspx", "/fn/onews.asp"}:
        return "portal_skipped"
    return "unknown"
