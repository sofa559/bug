"""負責禮貌請求、錯誤隔離與 redirect 防線，不決定頁面裡哪些連結屬於法規。"""

import time
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlsplit
from urllib.robotparser import RobotFileParser

import requests

from inventory.urls import allowed, normalize_url


class HttpClient:
    """串行 Session：每次請求間隔至少 1 秒，GET 最多重試一次，403 不重試。

    遇到 429 暫停該 host 本次所有後續請求；只記錄 Retry-After，不持續撞限速。
    預設附件最多讀 512 bytes、HTML 最多 3 MiB。Phase 3 顯式指定 download_path
    才保存完整二進位附件，仍受同一套延遲/robots/redirect 邊界保護。
    """

    def __init__(self, delay=1.0):
        self.session = requests.Session()
        self.session.headers["User-Agent"] = "NTPC-Law-SourceInventory/0.1 (academic source discovery; no bulk file download)"
        self.delay = delay
        self.last_request = 0
        self.paused_hosts = set()
        self.events = []
        self.robots = {}
        self.robots_notes = {}

    def close(self):
        self.session.close()

    def check_robots(self, url):
        """fetch 呼叫：每個官方 origin 先取得一次 robots；外站絕不請求。

        有效規則交給標準庫 RobotFileParser。404 或 HTML 假成功記錄為未知；
        403/429、網路錯誤、5xx 保守暫停該 origin，避免把失敗誤判為允許。
        """
        p = urlsplit(url)
        origin = f"{p.scheme}://{p.netloc}"
        if origin not in self.robots:
            result = self.fetch(origin + "/robots.txt", robots_request=True)
            body = result.get("body", b"")
            text = body.decode("utf-8", errors="replace")
            if result["status"] == "ok" and "user-agent:" in text.lower() and b"<html" not in body.lower():
                parser = RobotFileParser()
                parser.parse(text.splitlines())
                self.robots[origin] = parser
                self.robots_notes[origin] = "valid_robots"
            elif result.get("http_status") in (200, 404, 410) and result["status"] in {"ok", "http_error"}:
                self.robots[origin] = None
                self.robots_notes[origin] = "no_valid_robots_received; rules_unknown"
            else:
                self.robots[origin] = False
                self.robots_notes[origin] = "robots_unavailable; origin_paused"
        rule = self.robots[origin]
        return rule is None or (rule is not False and rule.can_fetch(self.session.headers["User-Agent"], url))

    def fetch(self, url, data=None, guard=None, attachment=False, robots_request=False, download_path=None, max_download_bytes=50 * 1024 * 1024):
        """探索器呼叫；input：URL、可選表單、redirect 範圍函式；output：結果 dict。

        每次 redirect 都先驗證網域、robots 與 guard，絕不先請求外站再判斷。
        預設維持 Phase 2 的 512 bytes 偵察。Phase 3 顯式傳 download_path 才串流下載
        完整附件（預設上限 50 MiB），先寫 .part，成功才原子換名，失敗保留 partial。
        錯誤轉成狀態值，讓其他來源能繼續。
        """
        current = url
        method = "POST" if data is not None else "GET"
        redirects = []
        for _ in range(8):
            if not allowed(current):
                return {"status": "external_redirect", "url": current, "redirects": redirects}
            if guard and not guard(current):
                return {"status": "scope_redirect", "url": current, "redirects": redirects}
            if urlsplit(current).hostname in self.paused_hosts:
                return {"status": "skipped_rate_limit", "url": current, "redirects": redirects}
            if not robots_request and not self.check_robots(current):
                return {"status": "robots_blocked", "url": current, "redirects": redirects}
            result = None
            for attempt in range(2 if method == "GET" else 1):
                wait = self.delay - (time.monotonic() - self.last_request)
                if wait > 0:
                    time.sleep(wait)
                event = {"time": datetime.now(timezone.utc).isoformat(), "method": method, "url": current, "attempt": attempt + 1, "purpose": "robots" if robots_request else "source"}
                self.last_request = time.monotonic()
                try:
                    with self.session.request(method, current, data=data if method == "POST" else None, timeout=(10, 25), stream=True, allow_redirects=False) as response:
                        status = response.status_code
                        headers = {k.lower(): v for k, v in response.headers.items() if k.lower() in {"content-type", "content-disposition", "content-length", "location", "retry-after"}}
                        event.update(http_status=status, headers=headers)
                        result = {"status": "ok", "http_status": status, "url": current, "headers": headers, "redirects": list(redirects)}
                        if status == 429:
                            self.paused_hosts.add(urlsplit(current).hostname)
                        if status in {301, 302, 303, 307, 308}:
                            target = normalize_url(current, response.headers.get("Location"))
                            result.update(status="redirect", target=target)
                        elif status >= 400:
                            result["status"] = "http_error"
                        elif status != 200:
                            result["status"] = "unexpected_http_status"
                        else:
                            # 先讀小段確認是否真的是 HTML；檔名端點回 HTML 錯誤頁也能辨認。
                            head = response.raw.read(512, decode_content=True)
                            ct = headers.get("content-type", "").lower()
                            cd = headers.get("content-disposition", "").lower()
                            looks_html = b"<html" in head.lower() or b"<!doctype html" in head.lower()
                            textual = ("html" in ct or looks_html or robots_request) and "attachment" not in cd and not head.startswith(b"%PDF-")
                            body = head
                            if download_path is not None and not textual:
                                target = Path(download_path)
                                target.parent.mkdir(parents=True, exist_ok=True)
                                partial = target.with_suffix(target.suffix + ".part")
                                count = len(head)
                                with partial.open("wb") as out:
                                    out.write(head)
                                    while True:
                                        chunk = response.raw.read(min(65536, max_download_bytes - count + 1), decode_content=True)
                                        if not chunk:
                                            break
                                        out.write(chunk)
                                        count += len(chunk)
                                        if count > max_download_bytes:
                                            result["status"] = "download_too_large"
                                            break
                                if result["status"] == "ok":
                                    partial.replace(target)
                                    result["file_path"] = str(target)
                                else:
                                    result["partial_file"] = str(partial)
                                result["downloaded_bytes"] = count
                            elif textual:
                                cap = 3 * 1024 * 1024
                                body += response.raw.read(cap - len(head) + 1, decode_content=True)
                                if len(body) > cap:
                                    result["status"] = "html_too_large"
                                    body = body[:cap]
                            result.update(body=body, is_html=looks_html or "html" in ct, encoding=response.encoding)
                            event["bytes_read"] = len(body)
                            if "downloaded_bytes" in result:
                                event["bytes_read"] = result["downloaded_bytes"]
                except requests.Timeout as exc:
                    result = {"status": "timeout", "url": current, "error": str(exc), "redirects": list(redirects)}
                except (requests.RequestException, OSError) as exc:
                    result = {"status": "connection_error", "url": current, "error": str(exc), "redirects": list(redirects)}
                except Exception as exc:
                    # 例如讀取 chunk 時 urllib3 直接拋錯；保留錯誤並繼續其他 URL。
                    result = {"status": "response_error", "url": current, "error": f"{type(exc).__name__}: {exc}", "redirects": list(redirects)}
                event["result"] = result["status"]
                if "error" in result:
                    event["error"] = result["error"]
                self.events.append(event)
                retryable = result["status"] in {"timeout", "connection_error", "response_error"} or result.get("http_status", 0) >= 500
                if retryable and method == "GET" and attempt == 0:
                    time.sleep(2)
                    continue
                break
            if result["status"] != "redirect":
                return result
            target = result.get("target")
            if not target:
                result["status"] = "invalid_redirect"
                return result
            redirects.append({"from": current, "to": target, "http_status": result["http_status"]})
            if target in {r["from"] for r in redirects}:
                return {"status": "redirect_loop", "url": target, "redirects": redirects}
            if result["http_status"] in {301, 302, 303}:
                method, data = "GET", None
            current = target
        return {"status": "too_many_redirects", "url": current, "redirects": redirects}
