"""流程入口：重用有效 inventory → Phase 3；--refresh-inventory 才重做探索。"""

import argparse
from pathlib import Path

from inventory.discovery import Discovery
from inventory.output import save_inventory


def discover():
    """main 呼叫；保留原 Phase 2 行為，探索後輸出清單。"""
    crawler = Discovery(evidence_dir="data/inventory/evidence")
    try:
        crawler.run()
    except KeyboardInterrupt:
        crawler.interrupted = True
        print("\n使用者中止，保存已發現來源與尚未完成的狀態。")
    finally:
        records, summary = crawler.results()
        save_inventory(records, summary, crawler.client.events)
        crawler.client.close()


def main():
    """CLI 呼叫；依參數決定重用/刷新，將 Source 清單交給文件流程，不在此解析。"""
    parser = argparse.ArgumentParser(description="新北市經發局 Phase 2 + Phase 3")
    parser.add_argument("--refresh-inventory", action="store_true", help="重新探索官方來源清單")
    parser.add_argument("--inventory-only", action="store_true", help="只執行/重用 Phase 2，停止於來源清單")
    parser.add_argument("--offline", action="store_true", help="只用既有 inventory/raw/evidence，不連線")
    parser.add_argument("--refresh-raw", action="store_true", help="重新請求本階段既有內容來源，仍不擴張範圍")
    args = parser.parse_args()
    if args.offline and (args.refresh_inventory or args.refresh_raw):
        parser.error("--offline 不能與 refresh 選項同時使用")
    path = Path("data/inventory/sources.json")
    if args.refresh_inventory or not path.exists():
        if args.offline:
            parser.error("沒有 inventory，offline 無法執行")
        discover()
    if args.inventory_only:
        return
    from documents.pipeline import read_inventory, run_documents
    run_documents(read_inventory(path), offline=args.offline, refresh_raw=args.refresh_raw)


if __name__ == "__main__":
    main()
