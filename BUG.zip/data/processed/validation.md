# Phase 3 驗證

通過表示清單與狀態如實，不表示 TABLE_REVIEW_REQUIRED/OCR_REQUIRED 已解決。

通過 59 / 59 項。

## 結構與內容檢查

- PASS：每份 Document 包含必要欄位
- PASS：Document ID 唯一
- PASS：所有 Source ID 與 URL 可回到 inventory
- PASS：185 筆來源保留完整 Source→Document 映射
- PASS：映射反向對應一致
- PASS：外站與受阻來源沒有 Document content
- PASS：所有 Phase 3 請求仍在官方範圍
- PASS：沒有重新請求受阻舊來源
- PASS：所有 raw 存在且 hash 等於保存紀錄
- PASS：所有文件使用的 raw 在 manifest
- PASS：TXT 檔名唯一，同名附表未覆蓋
- PASS：processed 根目錄無未被 metadata 引用的舊 TXT
- PASS：TXT 皆有非空正文且 hash 正確
- PASS：空內容未生成假的 TXT/hash
- PASS：所有 parent ID 存在且不指向自己
- PASS：parent title 與母文件一致
- PASS：duplicate_of 對應相同非空正文 hash
- PASS：72 law_system_page 聚合成 9 regulation
- PASS：C0040014：全部條文按原序保留
- PASS：C0040014：標題正確且無 menu/footer
- PASS：C0040020：全部條文按原序保留
- PASS：C0040020：標題正確且無 menu/footer
- PASS：C0040033：全部條文按原序保留
- PASS：C0040033：標題正確且無 menu/footer
- PASS：C0040034：全部條文按原序保留
- PASS：C0040034：標題正確且無 menu/footer
- PASS：C0040037：全部條文按原序保留
- PASS：C0040037：標題正確且無 menu/footer
- PASS：C0040044：全部條文按原序保留
- PASS：C0040044：標題正確且無 menu/footer
- PASS：C0040048：全部條文按原序保留
- PASS：C0040048：標題正確且無 menu/footer
- PASS：C0040060：全部條文按原序保留
- PASS：C0040060：標題正確且無 menu/footer
- PASS：C0040063：全部條文按原序保留
- PASS：C0040063：標題正確且無 menu/footer
- PASS：att_bb0ae9b35d0e8eef：附件母文件可追溯
- PASS：att_d125c9af3a23e340：附件母文件可追溯
- PASS：att_141acff681e27d54：附件母文件可追溯
- PASS：att_00f6edd9ab28defe：附件母文件可追溯
- PASS：att_73f462e17ea27fc2：附件母文件可追溯
- PASS：att_a3a4609c03f6cd3e：附件母文件可追溯
- PASS：att_152777595859c745：附件母文件可追溯
- PASS：att_a53b0ff97c2cb372：附件母文件可追溯
- PASS：att_006fdfcbd874cba7：附件母文件可追溯
- PASS：att_9cb3ac8b94e65d1c：附件母文件可追溯
- PASS：att_2e0232a9acc204db：附件母文件可追溯
- PASS：att_f9c837522a357774：無明確母文件時不猜
- PASS：att_9cb3ac8b94e65d1c：PDF TXT 有繁體文字而非亂碼
- PASS：att_9cb3ac8b94e65d1c：PDF 頁數正確
- PASS：att_a53b0ff97c2cb372：PDF TXT 有繁體文字而非亂碼
- PASS：att_a53b0ff97c2cb372：PDF 頁數正確
- PASS：att_73f462e17ea27fc2：PDF TXT 有繁體文字而非亂碼
- PASS：att_73f462e17ea27fc2：PDF 頁數正確
- PASS：公告真正空正文保留 EMPTY_CONTENT
- PASS：公告日期與生效日期分離
- PASS：空公告的兩個附件仍有母文件
- PASS：掃描 PDF 有 raw、無假正文 TXT
- PASS：人工視覺核對對應本次原始 PDF hash

## 抽查

```json
[
  {
    "kind": "regulation",
    "document_id": "reg_e96462df34b51d85",
    "title": "新北市政府經濟發展局處理違反工廠管理輔導法事件裁罰基準",
    "article_count": 3,
    "published_date": null,
    "amended_date": "2025-10-31",
    "effective_date": null,
    "finding": "對照完整 HTML；條文順序與全文保留，無導覽頁尾。"
  },
  {
    "kind": "regulation",
    "document_id": "reg_d0db8745289fb609",
    "title": "新北市政府經濟發展局辦理新北市都市計畫甲乙種工業區設置工業產品展示服務業企業營運總部及相關設施認定列管及輔導作業要點",
    "article_count": 7,
    "published_date": "2019-06-28",
    "amended_date": null,
    "effective_date": null,
    "finding": "對照完整 HTML；條文順序與全文保留，無導覽頁尾。"
  },
  {
    "kind": "regulation",
    "document_id": "reg_c65d31e15ac71550",
    "title": "新北市自助選物販賣事業管理自治條例",
    "article_count": 10,
    "published_date": "2022-11-30",
    "amended_date": null,
    "effective_date": "2023-09-01",
    "finding": "對照完整 HTML；條文順序與全文保留，無導覽頁尾。"
  },
  {
    "kind": "pdf",
    "document_id": "att_9cb3ac8b94e65d1c",
    "title": "新北市政府經濟發展局112年8月10日新北經商字第1121556723號令：訂定「新北市政府經濟發展局處理違反新北市自助選物販賣事業管理自治條例事件裁罰基準」，並自112年9月1日生效。－規定.pdf",
    "parse_status": "SUCCESS",
    "page_count": 1,
    "finding": "已檢查文字層及來源；視覺對照另見 manual_review.json。"
  },
  {
    "kind": "pdf",
    "document_id": "att_a53b0ff97c2cb372",
    "title": "新北市政府經濟發展局違反電子遊戲場業管理條例經命令停業處分逾期仍不履行怠金裁量基準－附表.PDF",
    "parse_status": "TABLE_REVIEW_REQUIRED",
    "page_count": 1,
    "finding": "已檢查文字層及來源；視覺對照另見 manual_review.json。"
  },
  {
    "kind": "pdf",
    "document_id": "att_73f462e17ea27fc2",
    "title": "新北市政府經濟發展局處理違反商業登記法事件裁罰基準－附表.PDF",
    "parse_status": "TABLE_REVIEW_REQUIRED",
    "page_count": 2,
    "finding": "已檢查文字層及來源；視覺對照另見 manual_review.json。"
  },
  {
    "kind": "announcement",
    "document_id": "ann_2116be0207f52590",
    "finding": "正文空白不生成 TXT；兩個 PDF 仍連回母公告。"
  },
  {
    "kind": "scanned_pdf",
    "document_id": "att_f9c837522a357774",
    "finding": "兩頁皆零文字；影像仍保存，未 OCR。"
  }
]
```

## 待複核文件

```json
[
  {
    "document_id": "ann_2116be0207f52590",
    "status": "EMPTY_CONTENT",
    "notes": [
      "公告正文 .worddisaplay 為空；原始公告標題保存在 announcement_statement，不製造正文 TXT。"
    ]
  },
  {
    "document_id": "att_bb0ae9b35d0e8eef",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_d125c9af3a23e340",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_73f462e17ea27fc2",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_a3a4609c03f6cd3e",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_152777595859c745",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_a53b0ff97c2cb372",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_006fdfcbd874cba7",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_2e0232a9acc204db",
    "status": "TABLE_REVIEW_REQUIRED",
    "notes": [
      "表格包含合併/跨行儲存格或偵測失敗；保留頁面文字及 table_data，但欄位與值的對應需人工核對。"
    ]
  },
  {
    "document_id": "att_f9c837522a357774",
    "status": "OCR_REQUIRED",
    "notes": [
      "附件由列表直接連結，inventory 未提供可確認的母法規/母公告；parent_document_id 保留 null，不依標題猜測。",
      "部分頁含影像/圖形但有效文字不足；需確認掃描/文字層，不執行 OCR。若有部分文字則保留並明示不完整。"
    ]
  }
]
```