# Phase 2 清單驗證

資料結構與抽查：通過。

一般來源從五個子分類各抽一筆；外部法規以來源列表 HTML 驗證，不連線外站。failed/unknown 另列，不等同驗證程式出錯。

## 全部檢查

- PASS：JSON 與 CSV 筆數一致
- PASS：id 與 source_url 唯一
- PASS：CSV 多值欄位與 JSON 完全一致
- PASS：所有實際請求均為允許官方網域
- PASS：沒有請求 related/search/portal/external skipped 來源
- PASS：所有引用都能回連 inventory
- PASS：非根來源都有發現位置
- PASS：所有分類條目數符合網站總筆數
- PASS：五個子分類全部探索
- PASS：沒有 pending 或中止
- PASS：附件皆只檢查最多 512 bytes
- PASS：已檢查 PDF 的 magic 證據未因重複發現遺失
- PASS：URL 未因舊編碼轉出 replacement character
- PASS：跳過外站有 title/category/來源位置
- PASS：一般來源：公司法
- PASS：一般來源：動產擔保交易法
- PASS：一般來源：商業登記法
- PASS：一般來源：工廠管理輔導法
- PASS：一般來源：電業法
- PASS：新北市法規系統：新北市政府經濟發展局處理違反石油管理法事件裁罰基準
- PASS：新北市法規系統：新北市政府處理違反電子遊戲場業管理條例事件裁罰基準
- PASS：新北市法規系統：新北市政府處理違反新北市資訊休閒業管理自治條例事件裁罰基準
- PASS：附件：修正新北市自助選物販賣事業管理自治條例第7條第3款「主管機關認定不宜於自助選物販賣機販售項目表」公告事項，並追溯自113年10月14日生效。
- PASS：附件：規定.pdf
- PASS：附件：附表.PDF
- PASS：外站略過：用電場所及專任電氣技術人員管理規則
- PASS：至少抽查 5 一般 + 3 法規 + 3 附件 + 1 外站

## 抽查紀錄

### 一般來源：公司法

- 分類：公司登記
- 類型：`external_skipped`；狀態：`external_skipped`
- URL：<http://law.moj.gov.tw/LawClass/LawContent.aspx?PCODE=J0080001>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 一般來源：動產擔保交易法

- 分類：動產擔保登記
- 類型：`external_skipped`；狀態：`external_skipped`
- URL：<http://law.moj.gov.tw/LawClass/LawContent.aspx?PCODE=G0380024>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 一般來源：商業登記法

- 分類：商業登記
- 類型：`external_skipped`；狀態：`external_skipped`
- URL：<http://law.moj.gov.tw/LawClass/LawAll.aspx?PCode=J0080004>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 一般來源：工廠管理輔導法

- 分類：工廠登記
- 類型：`external_skipped`；狀態：`external_skipped`
- URL：<http://law.moj.gov.tw/LawClass/LawContent.aspx?PCODE=J0030043>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 一般來源：電業法

- 分類：電器承裝業登記、法令規章
- 類型：`external_skipped`；狀態：`external_skipped`
- URL：<http://law.moj.gov.tw/LawClass/LawAll.aspx?PCode=J0030011>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 新北市法規系統：新北市政府經濟發展局處理違反石油管理法事件裁罰基準

- 分類：法令規章
- 類型：`law_system_page`；狀態：`success`
- URL：<https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040020>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 新北市法規系統：新北市政府處理違反電子遊戲場業管理條例事件裁罰基準

- 分類：法令規章
- 類型：`law_system_page`；狀態：`success`
- URL：<https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040033>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 新北市法規系統：新北市政府處理違反新北市資訊休閒業管理自治條例事件裁罰基準

- 分類：法令規章
- 類型：`law_system_page`；狀態：`success`
- URL：<https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040034>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

### 附件：修正新北市自助選物販賣事業管理自治條例第7條第3款「主管機關認定不宜於自助選物販賣機販售項目表」公告事項，並追溯自113年10月14日生效。

- 分類：法令規章
- 類型：`direct_attachment`；狀態：`success`
- URL：<https://www.economic.ntpc.gov.tw/Api/Upload/Download?file=940c1ee0-ff84-48bf-8abe-a7a39fc44be4.pdf&fileName=%E6%96%B0%E5%8C%97%E5%B8%82%E6%94%BF%E5%BA%9C%E7%B6%93%E6%BF%9F%E7%99%BC%E5%B1%95%E5%B1%80%E4%BB%A4%28%E6%96%B0%E5%8C%97%E7%B6%93%E5%95%86%E5%AD%97%E7%AC%AC1132270941%E8%99%9F%E4%BB%A4%E5%8F%8A%E4%BF%AE%E6%AD%A3%E9%A0%85%E7%9B%AE%E8%A1%A8%29.pdf>
- 父頁：[]
- 檔名／格式：新北市政府經濟發展局令(新北經商字第1132270941號令及修正項目表).pdf / pdf
- 已對照保存的 HTML 連結與顯示名稱。

### 附件：規定.pdf

- 分類：法令規章
- 類型：`direct_attachment`；狀態：`success`
- URL：<https://web.law.ntpc.gov.tw/DownloadNews.ashx?fileid=10150&msgid=6706>
- 父頁：["https://web.law.ntpc.gov.tw/news.aspx?msgid=6706"]
- 檔名／格式：規定.pdf / pdf
- 已對照保存的 HTML 連結與顯示名稱。

### 附件：附表.PDF

- 分類：法令規章
- 類型：`direct_attachment`；狀態：`success`
- URL：<https://web.law.ntpc.gov.tw/Download.ashx?pfid=0000249021>
- 父頁：["https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040020", "https://web.law.ntpc.gov.tw/Scripts/FLAWDOC01.aspx?fcode=C0040020&flno=2"]
- 檔名／格式：附表.PDF / pdf
- 已對照保存的 HTML 連結與顯示名稱。

### 外站略過：用電場所及專任電氣技術人員管理規則

- 分類：電器承裝業登記
- 類型：`external_skipped`；狀態：`external_skipped`
- URL：<http://law.moj.gov.tw/Law/LawSearchResult.aspx?k1=%E7%94%A8%E9%9B%BB%E5%A0%B4%E6%89%80&p=A&t=A1A2E1F1>
- 父頁：[]
- 檔名／格式：None / None
- 已對照保存的 HTML 連結與顯示名稱。

## 需注意的 unknown / failed

[
  {
    "title": "新北市政府辦理非都市土地丁種建築用地容許作工業設施使用之低污染事業認定作業要點",
    "url": "http://web.law.ntpc.gov.tw/Scripts/Newsdetail.asp?NO=1C0040004",
    "type": "unknown",
    "status": "robots_blocked",
    "notes": [
      "HTTP None; robots_blocked"
    ]
  }
]