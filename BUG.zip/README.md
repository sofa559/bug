# 新北市經發局法令規章資料管線

目前已加入 Phase 3。完整教學見 **[PHASE3_GUIDE.md](PHASE3_GUIDE.md)**，實際結果見 **[PHASE3_REPORT.md](PHASE3_REPORT.md)**。

```powershell
python -m pip install -r requirements.txt
python main.py                       # 重用有效 inventory/raw，執行到 Phase 3
python main.py --offline             # 只用本機 raw/evidence 重新解析，不連線
python main.py --refresh-inventory   # 明確要求重新做 Phase 2，接著 Phase 3
python main.py --refresh-raw         # 明確要求刷新內容原始檔，不擴張來源
python main.py --inventory-only      # 只建立或重用 inventory
python main.py --refresh-inventory --inventory-only  # 只重新探索 Phase 2
python validate_documents.py         # 驗證 Phase 3
```

`main.py` 現在默认執行到 Phase 3；**以下保留的章節是 Phase 2 模組說明，不代表 main.py 仍只輸出 inventory。**

## Phase 2：Source Inventory

唯一種子網址：<https://www.economic.ntpc.gov.tw/List/about-law>。

這個程式只建立來源清單：探索列表分頁、子分類、從列表發現的新北市法規、同法規條文、公告與附件 URL。**不下載完整附件，不轉 TXT，不做 OCR、LightRAG 或 Phase 3。**

## 執行

在本專案根目錄：

```powershell
python -m pip install -r requirements.txt
python main.py --inventory-only
```

若 Windows 終端顯示中文有問題，可使用 `python -X utf8 main.py`。JSON 以 UTF-8 保存，CSV 使用 UTF-8 BOM，方便 Excel 開啟。執行需要網路連線；Codex 沙箱可能另外要求網路執行許可，那是執行環境限制，不代表網站拒絕。

每次重新執行會重新探索並覆寫 `data/inventory/` 的輸出，不是斷點續跑。人工停止時會保存目前清單；必須看 summary 的 pending、failed、interrupted，不能把中斷結果當完整清單。

離線測試：

```powershell
python -m unittest discover -s tests -v
python validate_inventory.py
```

## 每個 Python 檔案負責什麼

### `main.py`：流程入口

- 職責：建立 `Discovery`、執行探索、交給輸出模組保存，最後關閉 Session。
- 為什麼需要：把「執行順序」與「爬取細節」分開，方便從這裡理解全貌。
- 套件：本機 `inventory.discovery` 提供探索器；`inventory.output` 負責寫檔。沒有額外第三方套件。
- input：執行 `python main.py`，起點由 `urls.py` 提供。
- output：四個 JSON/CSV 輸出檔案與終端統計。
- 關係：只協調模組，不解析 HTML。

### `inventory/__init__.py`：套件標記

- 職責與原因：讓 `inventory` 成為清楚的 Python 套件，供 main 和 tests 匯入。
- 套件：無。
- input/output：無資料輸入輸出，無網路或檔案副作用。
- 關係：其餘 inventory 模組所在的套件入口。

### `inventory/urls.py`：URL 正規化與範圍

- 職責：唯一 START_URL、允許的精確官方 hostname、相對網址轉換、初步分類、同法規代碼判斷。
- 為什麼需要：同一 URL 不同寫法會重複；外站及跨法規擴散必須在探索和轉址時使用一致規則。
- 套件：`urllib.parse` 拆解/重組 URL，`html` 解碼 HTML entity，`re` 辨認已觀察的代碼格式。都是 Python 標準庫。
- input：來源頁 URL、HTML href 或待判斷 URL。
- output：正規化 URL/None、分類字串、範圍布林值、法規代碼。
- 關係：`discovery.py` 與 `http_client.py` 共用。
- 重要函式：`normalize_url()` 用來去重但保留所有 query；`law_identity()` 只比較法規代碼，**不靠代碼拼造新 URL**；`classify_url()` 只是候選類型，HTML 仍要再確認。

### `inventory/http_client.py`：禮貌 HTTP 請求

- 職責：GET/POST、robots、timeout、有限 retry、逐跳 redirect 檢查、只讀小段附件、請求紀錄。
- 為什麼需要：把網路錯誤與資料解析分開，避免一個 URL 失敗使所有來源停止，也避免自動轉址偷偷請求外站。
- 套件：`requests` 向伺服器發 GET/POST 取得 HTML、headers 與檔頭；`time` 管理間隔；`datetime` 留下時間；`urllib.robotparser` 解析有效 robots；`urllib.parse` 取出 host/origin。
- input：URL、可選表單資料、redirect guard。
- output：包含 status、http_status、url、headers、有限 body 的 dict；請求日誌保存在 events。
- 關係：只由探索器呼叫，不自己搜尋網頁連結。
- `fetch()` 每次 redirect 都先驗證，`check_robots()` 每個 origin 只讀一次 robots。

網路策略：

- 串行請求，請求開始間隔至少 1 秒。
- timeout：連線 10 秒、讀取 25 秒。
- GET 的 timeout/連線錯誤/5xx 最多額外重試 1 次，重試前等 2 秒。
- POST 不自動重試，403/404 不重試。
- 429：記錄 Retry-After，暫停這個 host 本輪剩餘請求，不持續重試。
- 最多 8 跳 redirect；外站在請求前就阻擋。
- 二進位附件 application-level 最多讀 512 bytes，讀完即關閉，不保存完整附件。HTTP 底層可能緩衝額外網路資料，因此不宣稱網路封包總量恰好 512 bytes。
- HTML 最多 3 MiB，超過就標記，不無上限讀取。
- robots 404/410 或 200 HTML 錯誤頁標記「未取得有效規則」，**不等於已確認授權**；有效 Disallow 會遵守。robots 403/429/5xx/網路錯誤則停止該 origin 的正文請求。

### `inventory/discovery.py`：來源探索與關係

- 職責：queue、來源分類、URL 去重、列表及法規 DOM 解析、表單探索、附件資訊、統計。
- 為什麼需要：網站有不同頁型，不能只掃全頁所有 `<a>`；這裡決定哪些是目標內容。
- 套件：`BeautifulSoup` 將 HTML 轉成可搜尋 DOM；`collections.deque` 管待處理 queue、`Counter` 統計；`hashlib` 由 URL 產生穩定 ID（不是文件內容 hash）；`email.message` 讀下載檔名；`urllib.parse` 解析檔名參數；`re` 讀總筆數與副檔名；`datetime` 記錄時間。
- input：唯一 START_URL，以及 HTTP 回傳 HTML/headers。
- output：Source Record 清單、來源關係、摘要。正文僅用來辨認結構，不輸出 TXT。
- 關係：使用 urls 做規則、http_client 做請求；main 取得結果後交給 output。

重要函式的資料流：

| 函式 | 為什麼存在、input → output、誰呼叫 |
|---|---|
| `add_source()` | URL＋名稱＋來源關係 → 共用 Record，所有 parser 呼叫；同 URL 保留全部發現路徑 |
| `run()` | main 呼叫；queue → HTTP 結果 → parser；每筆錯誤隔離 |
| `parse_html()` | 真正 DOM → 選對 parser；未知結構標記，不猜 selector |
| `parse_list()` | 列表 DOM → items 與下一頁加入 queue；不寫死頁數、子分類 URL |
| `parse_law()` | 法規 DOM → 同法規頁、條文、所有條文表單、附件；不按歷史法規/搜尋 |
| `parse_attachments()` | 僅內容區下載連結 → 附件 Record；保留直接父頁和法規來源 |
| `attachment_metadata()` | filename/header/最多 512 bytes → 格式與證據，不轉文字 |
| `resolve_redirect()` | 最終 URL → 合併 redirect alias，不丟來源關係 |
| `results()` | 全部 Record → 修正 redirect 引用、補上重複分類、計算摘要 |
| `clean_parent_relationships()` | results 呼叫；返回基本資料的連結只保留發現關係，不反過來把條文頁當作基本資料的父頁 |

### `inventory/output.py`：輸出

- 職責：把資料寫成 JSON、CSV、摘要與請求紀錄。
- 為什麼需要：爬取邏輯不應混入 CSV 轉換細節。
- 套件：標準庫 `json` 保留巢狀來源關係；`csv` 正確引用含逗號/換行的欄位；`pathlib` 建資料夾與寫檔。
- input：records、summary、events。
- output：`sources.json`、`sources.csv`、`summary.json`、`requests.json`。
- 關係：由 main 在結束時呼叫 `save_inventory()`。

### `tests/test_inventory.py`：離線驗證

- 職責：驗證外站不請求、redirect 邊界、429、有限 retry、去重關係、附件讀取上限與輸出。
- 為什麼需要：邊界錯誤可能讓程式抓到整站或外站，值得用不打網站的測試先擋住。
- 套件：標準庫 `unittest` 與 `unittest.mock` 模擬 HTTP；`io.BytesIO` 模擬附件資料流；`tempfile` 使用測試暫存目錄；`pathlib/json` 驗證輸出；`BeautifulSoup` 建離線 DOM。
- input：合成 HTML/HTTP 回應，以及一個可選的 Phase 1 本機 HTML 樣本。
- output：測試結果；不向網站發送請求。缺少 Phase 1 樣本時只略過那一項。
- 關係：測試 urls、http_client、discovery、output 模組。

### `validate_inventory.py`：實際清單抽查

- 職責：獨立核對本次 JSON/CSV 與保存的原始 HTML，抽查 5 筆一般來源、3 筆法規、3 筆附件、1 筆外站。
- 為什麼需要：單元測試證明程式的特定行為；這個檔案確認實際執行產物和網站證據相符。
- 套件：`json/csv/pathlib` 讀寫輸出；`BeautifulSoup` 對照原始 HTML 的 href 和連結文字；`urllib.parse` 處理 URL；本機 `urls` 共用正規化和網域規則。
- input：`data/inventory/` 中 sources、summary、requests 與 evidence HTML。
- output：`validation.json`、`validation.md`、終端通過數；未通過時 exit code 1。
- 關係：執行 `python main.py` 後再執行，不爬網路、不更動來源清單。

## 程式整體資料流

```text
main.py
  → Discovery.add_source(START_URL)
  → queue 逐筆取出
  → HttpClient.fetch（robots、延遲、轉址邊界）
  → parse_html 根據 DOM 判別
      → 列表：items、下一頁、子分類
      → 法規：同法規連結、所有條文表單、附件
      → 公告：內容區附件
      → 附件：headers + 檔頭
      → 外站：只記錄，不請求
  → 新 URL 入 queue；重複 URL 合併關係
  → queue 空了
  → results 整理來源圖與統計
  → save_inventory 寫檔
```

## Source Record 欄位

為了保留一份法規被多個分類發現的關係，保留單一欄位相容閱讀，再增加陣列欄位。**完整關係請看陣列與 discovery_edges，不要只讀第一筆。**

| 欄位 | 意義 |
|---|---|
| id | 正規化來源 URL 的 SHA-256 前 20 碼加 src_；穩定來源 ID，非內容去重 |
| title | 網頁顯示的來源名稱；詳細頁標題可取代列表簡稱，原始文字留 observed_titles |
| category / categories | 第一個分類 / 所有分類；子列表自身以實際 heading 作分類 |
| source_type | 來源分類，不等於是否成功抓取 |
| source_url | 正規化、已確認轉址後的來源 URL；不任意刪除 query |
| original_urls | 合併前入口 URL/alias，例如 Api/Link |
| parent_url / parent_urls | 第一個 / 所有直接父內容頁；列表直接下載無法規父頁時為 null/[] |
| regulation_urls | 經發局帶入的法規來源脈絡，可用於將個別條文附件回連法規 |
| discovered_from | 在哪些頁面發現這筆 URL |
| discovery_edges | 每次發現的 from_url、parent_url、category、relation、link_text、original_url |
| domain | 精確 hostname，供範圍稽核 |
| crawl_status | success、external_skipped、skipped_scope、HTTP/解析錯誤等 |
| notes | 特殊狀況；沒有資料為 null |
| attachment_url | 附件來源 URL；非附件為 null |
| filename / file_type | 檔名與可能格式；無法判斷為 null |
| format_evidence | filename_extension、content_type、magic 等判斷依據 |
| future_handling | PDF/DOCX: PARSE_LATER；DOC: CONVERSION_REQUIRED；其他已知格式: UNSUPPORTED；未知: null |
| bytes_inspected | 附件實際交給程式檢查的 bytes 數量，不是檔案大小 |
| http_status / content_type / content_disposition | 實際 HTTP metadata，未請求為 null |
| redirect_chain | 轉址經過的 URL 與狀態碼 |
| response_encoding | requests 判讀的編碼；DOM 由原始 bytes 交給 BeautifulSoup 解析 |
| scope_law_id | bounded crawl 的同法規辨識碼，不是完整性或版本保證 |
| observed_at | 本次觀察時間，UTC ISO 格式 |
| evidence_html | 本次 HTML 原始證據的本機路徑；附件與未請求來源為 null |

JSON 缺少單值使用 `null`；沒有任何關係的集合使用 `[]`。CSV 的集合欄位是 JSON 字串，缺少單值為空欄位（空字串），沒有捏造日期或名稱。

### source_type

- `category_page`：主列表、子分類及其分頁。
- `regulation_page`：經發局站內、由實際語意 article 元素確認的內容頁；沒有樣本時不假造數量或 selector。
- `law_system_page`：同法規的基本資料、所有條文、個別條文。各 URL 各一筆，不等於各一份法規。
- `announcement_page`：新北市法規公告。
- `direct_attachment`：附件候選或已檢查附件，以 crawl_status 區別成功與否。
- `external_skipped`：外站 URL，絕不發請求，保留名稱與來源。
- `unknown`：目前不能可靠識別的結構或連結，notes 說明。
- **新增 `portal_skipped`**：整站資料庫入口不是單一法規；記錄而不深入，以免擴散到全市法規。
- **新增 `related_page_skipped`**：已知的相關法條、歷史法條、函釋、訴願等延伸入口；在個別條文內容區發現，記錄但不抓取，以免混成 unknown 或跨法規擴散。
- **新增 `search_skipped`**：列表實際出現的舊式 `Query4B.asp` 查詢入口；依要求不抓搜尋結果，保留原始 URL。

來源類型與狀態分開：例如 related_page_skipped + skipped_scope 表示「看到了連結，但依範圍不解析它」，不是 timeout。

## 輸出與完整性判斷

- `sources.json`：後续 Python pipeline 的來源陣列。
- `sources.csv`：同一批紀錄，供人工檢查。
- `summary.json`：每類數量、每分類頁數/總筆數核對、失敗、表單結果、robots 情況。
- `requests.json`：實際送出的每次請求，包括 retry/robots；不保存 Cookie 或表單 token。
- `evidence/*.html`：本次取得的 HTML 原始回應，供離線驗證；沒有完整 PDF/Word 附件。
- `validation.json` / `validation.md`：另執行驗證程式後的機器可讀/人工可讀抽查報告。

完整性看：所有已發現下一頁是否處理、分類 entries 是否符合 reported_total、沒有 pending、failed/unknown 是否已人工解讀。**總 URL 數不是獨立法規數，也不等於附件數。**未存取外站正文是設計範圍，不是遺漏。

URL 去重只在同 URL / 實際 redirect alias 上做；不合併同一法規的基本資料與全文，不把 `http`、`https` 擅自视為相同，也不合併不同 query ID。附件尚未做內容 hash。

## 已知邊界與 Phase 3 前風險

- 全國法規資料庫及其他外站不發 GET/HEAD，只有入口 metadata。
- 不跟法規整站入口、搜尋、法規沿革、相關法條往外擴散；可保存內容區出現的連結並標記 skipped_scope。
- 附件 bytes 只足夠確認部分 magic，不代表已驗證 PDF 完整、可抽文字或非掃描。ZIP/OLE magic 不能保證 DOCX/DOC 子類。
- 同一法規的版本、公告與現行正文是否一致，Phase 2 不判定。
- 檔名只作 metadata；尚未處理檔名安全落盤及完整檔案下載。
- 原站結構改變時應查看 unknown/failed，而不是默默當空清單。
- 429/robots/網路錯誤可能使本輪不完整；應待限制解除後重新執行，不能繞過。

到此停止 Phase 2。Phase 3 需使用者另外確認。
