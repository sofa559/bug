# Phase 3 教學：從 Source 到 Document

## 先學會執行

在專案根目錄執行：

```powershell
python -m pip install -r requirements.txt
python main.py
```

現有 sources.json 有效時直接重用，不從網站重新探索。raw 已存在且 checksum 一致時也重用，仍可重新執行 parser。

```powershell
python main.py --offline
```

這是練習 parser 最適合的模式：只能讀本機 raw/evidence；缺檔就標記 DOWNLOAD_FAILED，不偷偷連線。

```powershell
python main.py --refresh-inventory
python main.py --refresh-raw
python main.py --refresh-inventory --inventory-only
```

第一行重做來源發現再處理文件；第二行刷新既有內容來源，不擴張 scope；第三行只重做 Phase 2。offline 不可與 refresh 同時使用。

驗證：

```powershell
python -m unittest discover -s tests -v
python validate_inventory.py
python validate_documents.py
```

## 12 個觀念，用這個專案來理解

### 1. Source 和 Document 差在哪？

Source 像「取書位置」：書架、目錄頁、章節網址、下載連結。Document 才是「一本有完整內容、可辨認來源的書」。一個 Document 可以引用多個 Source。

本專案 Source 保存在 inventory/sources.json；Document 保存在 processed/metadata.json。不要用來源數字直接當成文件數量。

### 2. 為什麼 72 個頁面不是 72 份法規？

這 72 個 URL 是 9 個基本資料頁、9 個全文頁、54 個個別條文頁。就像一本書有封面、全文預覽、每章網址，不會因此變成幾十本書。

`group_sources()` 以 inventory 的 scope_law_id 分組：9 組各建立一個 regulation Document；所有條文是 primary_source_url，其餘頁保留於 source_urls/source_ids。

### 3. raw 和 processed 差在哪？

raw 是原件：政府送出的 HTML bytes、完整 PDF，不改正文。processed 是從原件抽出的文字及索引。

像保留考卷照片和自己整理的逐字稿。如果整理程式出錯，可以從原照片重做，不必再向老師拿一次。raw/manifest.json 記錄來源、檔案 hash、下載時間與 HTML evidence 的原觀察時間。

### 4. requests 在 Phase 3 做什麼？

它像負責取件的郵差：發送 HTTP 請求、遵守 robots 與延遲、接收下載回應。它不理解 PDF 中的法規。

仍使用 Phase 2 HttpClient。只有明確傳入 download_path 才下載完整附件；預設 fetch 仍只讀 512 bytes，不破壞 Phase 2 的行為。下載以區塊寫 .part，成功後換名；50 MiB 上限、逾時、有限 retry、逐跳 redirect 檢查都保留。

### 5. BeautifulSoup 在 Phase 3 做什麼？

它像看得懂網頁結構的整理員：從基本資料表格拿日期、從全文的 pre 拿正文，避開 menu/footer。

它不會自動理解「發布」和「生效」；我們必須看欄位標籤，分別存進不同日期欄位。

### 6. PyMuPDF 做什麼？

它打開 PDF，逐頁讀取文字層。掃描 PDF 像「文字的照片」，若沒有文字層，get_text 不會自動把照片變成字。

本案用 `pymupdf.open()`、`page.get_text('text', sort=True)`，並用 `page.find_tables()` 保留基本表格資料。沒有调用 OCR。[官方文字擷取文件](https://pymupdf.readthedocs.io/en/latest/recipes-text.html)

### 7. python-docx 做什麼？

它读取 DOCX 內的段落和表格。`iter_inner_content()` 讓段落與表格照原文件順序輸出，避免先全部段落、再全部表格而打乱顺序。本次網站沒有 DOCX，因此用離線合成檔測試基本能力。[官方表格文件](https://python-docx.readthedocs.io/en/latest/api/table.html)

它不能直接读取舊 DOC；DOC 保留原檔並標記 CONVERSION_REQUIRED。

### 8. SHA-256 content hash 是什麼？

它像正文的數位指紋。輸入同一段清理後文字，就得到同一串固定長度的值；正文變動，通常就得到不同值。

本案只 hash 正文，不含「來源網址、文件 ID」等 TXT header，否則相同正文但不同網址會被誤認成不同內容。空文字不產生 hash，避免所有失敗文件被當成重複。

### 9. URL 去重和內容去重差在哪？

- URL 去重：「同一個取書地址不要跑兩次。」Phase 2 保留分類與發現路徑。
- 內容去重：「不同地址拿到相同逐字內容，標記它們是同一內容。」Phase 3 用正文 SHA-256。

內容相同仍保留 Document、raw、TXT，設 duplicate=true、duplicate_of=第一份的 ID。本案不做近似文字比對；排版或文字不同，即使語意近似也不合併。

### 10. parent_document_id 為什麼重要？

「附表.PDF」本身無法告訴你它是石油管理、商業登記，還是其他法規。parent_document_id 像書的附件標籤，讓附件回到正確母法規或母公告。

父關係只取自 Phase 2 的 parent_urls/regulation_urls，不依相似標題猜測。11 個附件有可確認父文件；列表直接連到的一份掃描 PDF 沒有明確父文件，保留 null。共享附件可保留 parent_document_ids 陣列。

### 11. metadata.json 為什麼不能省？

TXT 是內容，metadata 是索引卡：記錄誰發布、來自哪裡、哪份原件、哪個 parser 狀態、是否重複。

只交 TXT，組員可能把「需 OCR」「需表格核對」誤當成已完成文件，也無法追查日期或來源。

### 12. 為什麼不能合成超大 TXT？

一本法規結束、另一份附件開始，邊界和日期不同。全部黏在一起後，難以知道某段裁罰屬於哪份法規，也不方便單独重跑失敗文件。

保留一個 Document 一個 TXT（有可用正文時），讓之後組員可以保留文件邊界再自行決定切分策略。本階段不替 LightRAG 做 chunk 或 embedding。

## 檔案與責任

### main.py（修改）

- 為何需要：只管執行順序和 CLI，不混入下載/解析實作。
- 套件：標準庫 argparse 讀參數、pathlib 查 inventory；匯入原 inventory 模組和新的 pipeline。
- input：CLI 參數與既有檔案。
- output：Phase 2（必要時）與 Phase 3 結果。
- `main()` 決定重用/刷新；`discover()` 保留原探索行為。

### inventory/http_client.py（擴充）

- 為何需要：沿用同一套 HTTP 規則，避免 Phase 3 繞過 Phase 2 限制。
- 套件：原 requests、time、datetime、urllib，新增 pathlib 寫串流檔案。
- input：URL、guard、可選 download_path。
- output：原 response dict；完整下載時增加 file_path/downloaded_bytes，失敗保存 partial。
- 預設呼叫仍是 Phase 2 行為，只有 RawStore 明確要求完整下載。

### documents/__init__.py（新增）

- 讓這個目錄成為清楚的 Python 套件；無額外套件、無 input/output 副作用。

### documents/cleaners.py（新增）

- 為何需要：所有 parser 共享同一套保守清理與正文 hash。
- 套件：re 處理換行/控制字元，hashlib 產生 SHA-256。
- input：原文字、標題、Document 陣列。
- output：清理文字、安全短檔名、hash、重複標記。
- 不刪金額、日期、頁码、句子，不硬接斷行，不壓縮表格內部的欄間空白。

### documents/parsers.py（新增）

- 為何需要：把「從 raw 理解格式」獨立，改 parser 時不必改下載器。
- 套件：BeautifulSoup 解析 HTML；pymupdf 讀 PDF；docx 讀 DOCX；zipfile 核對 DOCX/其他 ZIP 格式；re/datetime 解析明確日期；pathlib/urllib 處理檔案與條號連結。
- input：HTML bytes、完整 raw 檔案 path。
- output：`text`、`parse_status`、`metadata`、`notes`，不發 HTTP。
- table_data 保留 PyMuPDF 的儲存格矩陣，正文保留頁面純文字；沒有複雜重建表格。

### documents/raw.py（新增）

- 為何需要：保證原件保留、快取可驗證、網路只走既有 HttpClient。
- 套件：hashlib 核對原 bytes；json/pathlib/datetime 管 manifest；email.message 讀 Content-Disposition；本機 parsers 判格式。
- input：inventory Source、offline/refresh 設定。
- output：raw HTML/PDF/Word/other、manifest、累積 requests_history。
- HTML 預設原樣複製 Phase 2 evidence，PDF 則正式下載一次；以 source ID 命名，不用附表.PDF 當唯一檔名。

### documents/pipeline.py（新增）

- 為何需要：負責 Source→Document 的規則、父關係、錯誤隔離及輸出，不讓 main 過度膨脹。
- 套件：json/pathlib 寫檔、collections 分組統計、hashlib 穩定 Document ID、datetime 記錄時間、urllib 辨認頁型；使用 cleaners/parsers/raw。
- input：有效 inventory records。
- output：TXT、metadata.json、source_document_map.json、summary.json、當次 requests.json。
- 過期的「前次已知 TXT」不再被 metadata 引用時，移入 processed/_previous，而非混在本輪根目錄；不刪使用者其他檔案。

### tests/test_documents.py（新增）

- 為何需要：驗證清理、命名、內容去重、9 份聚合、父關係、PDF magic、各解析狀態及錯誤隔離。
- 套件：unittest/mock/tempfile/pathlib/json；PyMuPDF 和 python-docx 只建立暫存測試文件；沿用 test_inventory.FakeResponse，不連線。
- input：合成檔與現有 inventory 樣本。
- output：15 個 Phase 3 測試，加上原 16 個 Phase 2 測試。

### validate_documents.py（新增）

- 為何需要：單元測試之外，再確認這次實際文件，而不是只看程式沒 crash。
- 套件：json/pathlib/re 讀輸出；BeautifulSoup 對照原 HTML；pymupdf 核對 PDF；既有 file_hash/content_hash 核對完整性。
- input：metadata、TXT、raw、inventory、來源映射及人工核對記錄。
- output：processed/validation.json、validation.md；檢查失敗 exit 1。
- 無網路；其中 3 法規、3 PDF、公告、掃描 PDF 共 8 筆詳細樣本，另對全部 9 法規做完整性檢查。

## 重要函式，不逐行翻譯

| function | 誰呼叫／為什麼存在 | input → output |
|---|---|---|
| read_inventory | main，先檢查來源清單有效性 | JSON path → 唯一 Source records |
| make_document | group_sources，建立獨立模型 | Source group → 缺值為 null 的 Document |
| group_sources | run_documents，控制文件邊界 | 185 Sources → 22 Document plans |
| RawStore.cached | html/attachment，避免重下載與損坏快取 | Source → 通過 checksum 的 raw entry/None |
| RawStore.html | pipeline，保存原始 HTML | Source → raw HTML manifest |
| RawStore.attachment | pipeline，正式下載既有附件 | Source → 完整 raw manifest |
| RawStore.record | raw 保存後，保留來源和完整性 | 檔案＋Source → manifest entry |
| detect_file_type | RawStore，避免只看 .pdf | raw magic＋headers/檔名 → 格式與證據 |
| parse_regulation | pipeline，全文聚合與日期 | 全文/基本資料 HTML → 正文與日期/條號 |
| parse_announcement | pipeline，空正文不造內容 | 公告 HTML → 正文或 EMPTY_CONTENT |
| parse_pdf | parse_attachment，逐頁抽文字 | PDF path → 正文、頁數、表格、品質狀態 |
| parse_docx | parse_attachment，保留段落表格順序 | DOCX path → 正文及簡單表格 |
| parse_attachment | pipeline，隔離單一 parser 故障 | path＋格式 → 統一結果 dict |
| parse_date / explicit_effective_date | HTML parser/來源標題，分離日期語意 | 明確年月日 → ISO 日期＋證據；相對日期不猜 |
| clean_text | parsers/輸出，只移除格式雜訊 | 原文字 → 保守清理文字 |
| safe_filename | TXT 輸出，避免非法字元/長路徑 | title → 安全短檔名；另加 ID 防撞 |
| content_hash | TXT 輸出，指紋只看正文 | 非空正文 → SHA-256；空字串 → null |
| mark_duplicates | pipeline，保留但標記完全相同正文 | Documents → 原地 duplicate/duplicate_of |
| write_text_document | pipeline，讓 TXT 可閱讀可追查 | Document＋正文 → 唯一 TXT/hash |
| run_documents | main，整批處理且錯誤隔離 | Sources → raw/processed/metadata |
| validate | validate_documents CLI，核對實際产物 | 三個資料目錄 → 驗證報告 |

## metadata.json 的結構與規則

頂層是 Document 陣列。主要欄位：

```text
document_id, title, document_type, source_name
source_ids[], source_urls[], primary_source_url, source_roles[]
categories[]
parent_document_id, parent_title, parent_document_ids[]
published_date, amended_date, effective_date, announcement_date, date_evidence[]
raw_files[], raw_source_ids[], processed_file
parse_status, review_flags[], notes[]
content_hash, duplicate, duplicate_of
```

法規另有 law_id、article_labels、article_numbers；PDF 另有 page_count、page_quality、table_data。這些欄位是為了驗證完整性和表格品質，不是 RAG 特徵。

日期為 ISO `YYYY-MM-DD`。明確民國年月日轉西元；同時保留原日期文字與來源於 date_evidence。沒有資料用 null，不用公告日期推生效日，不把母文件日期直接複製成附件日期。

掃描 PDF 的生效日期可來自原列表標題中明寫的日期（date_evidence.origin=inventory_link_title），這不是 OCR，也沒有補寫掃描正文。

## parse_status

| 狀態 | 意義與 TXT 行為 |
|---|---|
| SUCCESS | 有可用文字且未觸發目前品質警示，仍非法律正確性保證 |
| EMPTY_CONTENT | 實際正文空，metadata 保留，processed_file=null |
| OCR_REQUIRED | 影像/圖形頁文字不足，需確認文字層；無文字時不輸出 TXT，有部分文字時 header 明示不完整 |
| CONVERSION_REQUIRED | 舊 DOC 只保留 raw，不自動轉檔 |
| UNSUPPORTED | XLS/XLSX/ODT/ZIP/其他格式保存 raw，不解析 |
| DOWNLOAD_FAILED | 下載/快取取得失敗，保留能保存的 error/partial |
| PARSE_FAILED | raw 存在但 parser/結構/輸出出錯，不把失敗當空正文 |
| TABLE_REVIEW_REQUIRED | 合併/跨行欄位或表格偵測失敗；TXT 和 table_data 保留，不能直接當可靠欄值 |
| TEXT_REVIEW_REQUIRED | 新增：抽取出 U+FFFD replacement character，文字品質需核對；本次 0 |

`OCR_REQUIRED`、`TABLE_REVIEW_REQUIRED` 是保守品質規則，並非自動證明每一處都壞掉。人工核對樣本則提供實際證據。若狀態重疊，OCR 優先，其他警示仍留在 review_flags。

## 原始資料與結果不混淆

```text
data/raw/
  html/                 19 份原始 HTML（9基本資料＋9全文＋1公告）
  pdf/                  12 份完整 PDF
  word/                 目前空
  other/                目前空；未支援格式/partial/error response 可放此處
  manifest.json         Source→raw、bytes hash、時間與 headers
  requests_history.json 累積下載/robots 請求紀錄

data/processed/
  *.txt                 20 份有正文的 TXT
  metadata.json         22 個 Document，包含無正文/需 OCR 狀態
  source_document_map.json 185 個 Source 的去向與原 crawl_status
  summary.json          當次統計
  requests.json         當次請求；offline 執行為 []
  validation.json/md    自動核對
  manual_review.json    視覺檢查與對應 raw hash
```

22 個 Document 不等於 22 份可直接匯入的 TXT：1 空公告與 1 掃描 PDF 沒有可用正文，因此只有 20 TXT。這避免生成假的成功文件。

HTML 使用的是 Phase 2 快照，附件是 Phase 3 下載時的內容，時間在 raw manifest 中。這不是現行法規或版本一致性的保證。先停在 Phase 3，尚未建立任何 RAG、OCR、API 或 embedding。
