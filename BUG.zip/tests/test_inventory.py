"""離線驗證爬取邊界與資料關係；不向政府網站發送請求。"""

import json
import tempfile
import unittest
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

from bs4 import BeautifulSoup

from inventory.discovery import Discovery
from inventory.http_client import HttpClient
from inventory.output import save_inventory
from inventory.urls import START_URL, allowed, normalize_url


class FakeResponse:
    def __init__(self, status=200, body=b"", headers=None):
        self.status_code = status
        self.headers = headers or {}
        self.raw = self
        self.stream = BytesIO(body)
        self.encoding = "utf-8"

    def read(self, size, decode_content=True):
        return self.stream.read(size)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class InventoryTests(unittest.TestCase):
    """unittest discover 呼叫；input 為合成頁/Phase 1 樣本，output 為測試通過或失敗。"""

    def test_normalize_keeps_query_values_duplicates_and_removes_fragment(self):
        actual = normalize_url(START_URL, "?b=&amp;fcode=C0040063&a=2&a=1#part")
        self.assertEqual(actual, START_URL + "?a=1&a=2&b=&fcode=C0040063")
        self.assertIsNone(normalize_url(START_URL, "javascript:void(0)"))
        self.assertFalse(allowed("https://web.law.ntpc.gov.tw.evil.example/path"))
        self.assertFalse(allowed("https://web.law.ntpc.gov.tw:8080/path"))

    def test_legacy_percent_bytes_are_never_redecoded_as_utf8(self):
        url = "http://web.law.ntpc.gov.tw/Scripts/Query4B.asp?Lcode=C0150108&FullDoc=%B3%D2%A6%ED"
        normalized = normalize_url(START_URL, url)
        self.assertIn("FullDoc=%B3%D2%A6%ED", normalized)
        self.assertNotIn("%EF%BF%BD", normalized)
        d = Discovery()
        r = d.add_source(url, "舊查詢")
        self.assertEqual(r["source_type"], "search_skipped")
        self.assertEqual(len(d.queue), 0)
        d.client.close()

    def test_duplicate_retains_relations_and_propagates_category(self):
        d = Discovery()
        url = "https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040063"
        r = d.add_source(url, "法規", ["甲"], START_URL)
        attachment = d.add_source("https://web.law.ntpc.gov.tw/Download.ashx?pfid=123", "a.pdf", ["甲"], url, parent=url)
        d.add_source(url, "法規", ["乙"], START_URL + "?page=2")
        d.results()
        self.assertEqual(r["categories"], ["甲", "乙"])
        self.assertEqual(attachment["categories"], ["甲", "乙"])
        self.assertEqual(len(r["discovered_from"]), 2)
        self.assertEqual(len(d.records), 2)
        d.client.close()

    def test_external_is_recorded_but_never_queued(self):
        d = Discovery()
        r = d.add_source("https://law.moj.gov.tw/LawClass/LawAll.aspx?PCode=A", "外部法規", ["法令規章"], START_URL)
        self.assertEqual(r["source_type"], "external_skipped")
        self.assertEqual(list(d.queue), [])
        d.client.close()

    def test_redirect_to_external_never_requested(self):
        client = HttpClient(delay=0)
        response = FakeResponse(302, headers={"Location": "https://law.moj.gov.tw/a"})
        with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=response) as request:
            result = client.fetch(START_URL)
        self.assertEqual(result["status"], "external_redirect")
        self.assertEqual(request.call_count, 1)
        client.close()

    def test_429_pauses_host_without_retry(self):
        client = HttpClient(delay=0)
        with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=FakeResponse(429, headers={"Retry-After": "3600"})) as request:
            first = client.fetch(START_URL)
            second = client.fetch(START_URL + "?page=2")
        self.assertEqual(first["http_status"], 429)
        self.assertEqual(second["status"], "skipped_rate_limit")
        self.assertEqual(request.call_count, 1)
        client.close()

    def test_403_and_404_not_retried(self):
        for status in [403, 404]:
            client = HttpClient(delay=0)
            with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=FakeResponse(status)) as request:
                self.assertEqual(client.fetch(START_URL)["status"], "http_error")
            self.assertEqual(request.call_count, 1)
            client.close()

    def test_500_retries_once_then_returns_failure(self):
        client = HttpClient(delay=0)
        with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=FakeResponse(500)) as request, patch("inventory.http_client.time.sleep"):
            result = client.fetch(START_URL)
        self.assertEqual(result["http_status"], 500)
        self.assertEqual(request.call_count, 2)
        client.close()

    def test_binary_is_limited_to_512_bytes(self):
        client = HttpClient(delay=0)
        response = FakeResponse(body=b"%PDF-1.7" + b"a" * 10000, headers={"Content-Type": "application/unknown"})
        with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=response):
            result = client.fetch(START_URL, attachment=True)
        self.assertEqual(len(result["body"]), 512)
        self.assertEqual(response.stream.tell(), 512)
        client.close()

    def test_attachment_filename_header_and_pdf_magic(self):
        d = Discovery()
        r = d.add_source("https://web.law.ntpc.gov.tw/Download.ashx?pfid=1")
        d.attachment_metadata(r, {"body": b"%PDF-1.7", "headers": {"content-type": "application/octet-stream", "content-disposition": "attachment; filename*=utf-8''%e9%99%84%e8%a1%a8.PDF"}})
        self.assertEqual(r["filename"], "附表.PDF")
        self.assertEqual(r["file_type"], "pdf")
        self.assertEqual(r["future_handling"], "PARSE_LATER")
        d.add_source(r["source_url"], "另一次發現.pdf", ["另一分類"], START_URL)
        self.assertIn("magic:%PDF-", r["format_evidence"])
        self.assertEqual(r["filename"], "附表.PDF")
        unknown = d.add_source("https://web.law.ntpc.gov.tw/Download.ashx?pfid=2")
        d.attachment_metadata(unknown, {"body": b"PK\x03\x04"})
        self.assertIsNone(unknown["file_type"])
        d.client.close()

    def test_list_uses_actual_next_link_and_ignores_menu(self):
        d = Discovery()
        r = d.add_source(START_URL)
        soup = BeautifulSoup('<nav><a href="/bad">新聞</a></nav><main id="main"><h2 class="main-title">法令規章</h2><div class="item"><a href="/List/new-category"><div class="font">新分類</div></a></div></main><div class="pagination-container"><a rel="next" href="?page=123">next</a></div>', "html.parser")
        d.parse_html(r, soup)
        self.assertIn(START_URL + "?page=123", d.records)
        self.assertNotIn("https://www.economic.ntpc.gov.tw/bad", d.records)
        d.client.close()

    def test_law_scope_does_not_expand_related_laws(self):
        d = Discovery()
        url = "https://web.law.ntpc.gov.tw/Scripts/FLAWDAT0202.aspx?fcode=C0040048"
        r = d.add_source(url)
        soup = BeautifulSoup('<div class="content2"><a id="cph_content_lawheader_hlkLNNAME" href="FLAWDAT01.aspx?lncode=1C0040048">原法規</a><pre>正文</pre><a href="FLAWDAT0202.aspx?fcode=C9999999">另一法規</a></div>', "html.parser")
        d.parse_html(r, soup)
        other = d.records["https://web.law.ntpc.gov.tw/Scripts/FLAWDAT0202.aspx?fcode=C9999999"]
        self.assertEqual(other["crawl_status"], "skipped_scope")
        d.client.close()

    def test_law_backlink_is_discovery_not_parent_cycle(self):
        d = Discovery()
        basic = "https://web.law.ntpc.gov.tw/Scripts/FLAWDAT01.aspx?lncode=1C0040048"
        full = "https://web.law.ntpc.gov.tw/Scripts/FLAWDAT0202.aspx?fcode=C0040048"
        r = d.add_source(basic, "原法規", ["法令規章"], START_URL)
        d.add_source(full, "原法規", ["法令規章"], basic, parent=basic, relation="all_articles_form")
        d.add_source(basic, "原法規", ["法令規章"], full, parent=full, relation="same_law_link")
        d.results()
        self.assertIsNone(r["parent_url"])
        self.assertIn(full, r["discovered_from"])
        self.assertEqual(d.records[full]["parent_url"], basic)
        d.client.close()

    def test_saved_phase1_article_attachments(self):
        fixture = Path("phase1_evidence/article2.html")
        if not fixture.exists():
            self.skipTest("未附 Phase 1 本機證據")
        d = Discovery()
        r = d.add_source("https://web.law.ntpc.gov.tw/Scripts/FLAWDOC01.aspx?fcode=C0040048&flno=2", categories=["法令規章"])
        d.parse_html(r, BeautifulSoup(fixture.read_bytes(), "html.parser"))
        files = [x for x in d.records.values() if x["source_type"] == "direct_attachment"]
        self.assertEqual(len(files), 3)
        self.assertTrue(all(r["source_url"] in x["parent_urls"] for x in files))
        self.assertFalse(any("操作手冊" in (x["title"] or "") for x in d.records.values()))
        d.client.close()

    def test_one_failure_does_not_stop_queue(self):
        d = Discovery()
        one = "https://www.economic.ntpc.gov.tw/List/one"
        two = "https://www.economic.ntpc.gov.tw/List/two"
        d.add_source(one)
        d.add_source(two)
        with patch.object(d.client, "fetch", return_value={"status": "timeout", "url": one}) as fetch:
            d.run()
        self.assertEqual(fetch.call_count, 3)  # 兩個測試 URL 加唯一正式 START_URL。
        self.assertTrue(all(r["crawl_status"] == "timeout" for r in d.records.values()))
        d.client.close()

    def test_json_csv_preserve_non_ascii_and_arrays(self):
        d = Discovery()
        d.add_source("https://law.moj.gov.tw/a", "中文來源", ["甲", "乙"], START_URL)
        records, summary = d.results()
        with tempfile.TemporaryDirectory() as directory, patch("builtins.print"):
            save_inventory(records, summary, [], directory)
            saved = json.loads((Path(directory) / "sources.json").read_text(encoding="utf-8"))
            self.assertEqual(saved[0]["categories"], ["甲", "乙"])
            self.assertTrue((Path(directory) / "sources.csv").read_bytes().startswith(b"\xef\xbb\xbf"))
        d.client.close()


if __name__ == "__main__":
    unittest.main()
