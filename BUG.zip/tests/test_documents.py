"""Phase 3 離線測試：只用暫存合成文件與既有 HTML，不連政府網站。"""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pymupdf
from docx import Document as WordDocument

from documents.cleaners import clean_text, content_hash, mark_duplicates, safe_filename
from documents.parsers import detect_file_type, parse_attachment, parse_announcement, parse_regulation, explicit_effective_date
from documents.pipeline import group_sources, read_inventory, run_documents
from documents.raw import RawStore, RawUnavailable
from inventory.http_client import HttpClient
from test_inventory import FakeResponse


class DocumentTests(unittest.TestCase):
    def test_cleaning_preserves_meaning_numbers_and_columns(self):
        self.assertEqual(clean_text("\ufeff第一條\r\r\n\x00罰鍰  30,000 元\n\n\n公司：甲\u200b  "), "第一條\n罰鍰  30,000 元\n\n公司：甲")
        self.assertEqual(clean_text("欄一\t欄二\nA    100"), "欄一\t欄二\nA    100")

    def test_filename_windows_reserved_and_length(self):
        self.assertEqual(safe_filename("CON"), "_CON")
        self.assertNotIn("/", safe_filename('附表/測試:*?.pdf'))
        self.assertLessEqual(len(safe_filename("長" * 200)), 65)
        self.assertFalse(safe_filename("name. ").endswith("."))

    def test_hash_and_duplicates_are_body_only(self):
        self.assertEqual(content_hash("第一條\r\n內容"), content_hash("第一條\n內容"))
        docs = [{"document_id": "a", "content_hash": content_hash("正文")}, {"document_id": "b", "content_hash": content_hash("正文")}, {"document_id": "c", "content_hash": None}]
        mark_duplicates(docs)
        self.assertEqual(docs[1]["duplicate_of"], "a")
        self.assertFalse(docs[2]["duplicate"])
        self.assertNotEqual(content_hash("罰鍰100元"), content_hash("罰鍰1000元"))

    def test_actual_inventory_groups_72_sources_into_9_regulations(self):
        if not Path("data/inventory/sources.json").exists():
            self.skipTest("實際 inventory 未附")
        plans = group_sources(read_inventory())
        laws = [p for p in plans if p["document"]["document_type"] == "regulation"]
        self.assertEqual(len(laws), 9)
        self.assertEqual(sum(len(p["sources"]) for p in laws), 72)
        self.assertTrue(all("FLAWDAT0202" in p["primary"]["source_url"] for p in laws))
        files = [p["document"] for p in plans if p["document"]["document_type"] == "attachment"]
        self.assertEqual(len(files), 12)
        self.assertEqual(sum(d["parent_document_id"] is None for d in files), 1)
        ids = {p["document"]["document_id"] for p in plans}
        self.assertTrue(all(d["parent_document_id"] in ids for d in files if d["parent_document_id"]))

    def test_regulation_sequence_and_distinct_dates(self):
        raw = b'<html><div class="content2"><td id="cph_content_lawheader_law"><a id="cph_content_lawheader_hlkLNNAME">LAW</a></td><table><tr><td class="col-th"><a href="?flno=1">1</a></td><td class="col-td"><pre>FIRST</pre></td></tr><tr><td class="col-th"><a href="?flno=2">2</a></td><td class="col-td"><pre>SECOND</pre></td></tr></table></div><footer>BAD</footer></html>'
        result = parse_regulation(raw)
        self.assertEqual(result["metadata"]["article_numbers"], ["1", "2"])
        self.assertNotIn("BAD", result["text"])
        self.assertIsNone(result["metadata"]["amended_date"])
        self.assertEqual(explicit_effective_date("自中華民國一百十二年九月一日施行。")[0], "2023-09-01")
        self.assertIsNone(explicit_effective_date("自發布日生效。")[0])

    def test_empty_announcement_never_uses_title_as_body(self):
        result = parse_announcement('<div class="content"><div class="edit-title"><div class="col-th">112.08.10</div><span class="lawname">公告自112年9月1日生效。</span></div><div class="worddisaplay"></div></div>')
        self.assertEqual(result["parse_status"], "EMPTY_CONTENT")
        self.assertEqual(result["text"], "")
        self.assertEqual(result["metadata"]["announcement_date"], "2023-08-10")
        self.assertEqual(result["metadata"]["effective_date"], "2023-09-01")

    def test_pdf_magic_and_parse_status(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / "download.bin"
            with pymupdf.open() as pdf:
                page = pdf.new_page()
                page.insert_text((72, 72), "Article 1: This is a complete test document with enough real text.")
                pdf.save(p)
            self.assertEqual(detect_file_type(p, "wrong.doc", "application/unknown")[0], "pdf")
            result = parse_attachment(p, "pdf")
            self.assertEqual(result["parse_status"], "SUCCESS")
            self.assertIn("Article 1", result["text"])
            p.write_bytes(b"%PDF-not-a-valid-document")
            self.assertEqual(parse_attachment(p, "pdf")["parse_status"], "PARSE_FAILED")

    def test_scanned_candidate_blank_and_unsupported_statuses(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / "image.pdf"
            with pymupdf.open() as pdf:
                page = pdf.new_page()
                page.draw_rect(pymupdf.Rect(30, 30, 100, 100), fill=(0, 0, 0))
                pdf.save(p)
            self.assertEqual(parse_attachment(p, "pdf")["parse_status"], "OCR_REQUIRED")
            p = Path(root) / "blank.pdf"
            with pymupdf.open() as pdf:
                pdf.new_page()
                pdf.save(p)
            self.assertEqual(parse_attachment(p, "pdf")["parse_status"], "EMPTY_CONTENT")
            self.assertEqual(parse_attachment(p, "doc")["parse_status"], "CONVERSION_REQUIRED")
            self.assertEqual(parse_attachment(p, "xlsx")["parse_status"], "UNSUPPORTED")

    def test_docx_paragraphs_and_table_in_document_order(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / "word.bin"
            doc = WordDocument()
            doc.add_paragraph("開始")
            table = doc.add_table(rows=1, cols=2)
            table.cell(0, 0).text = "金額"
            table.cell(0, 1).text = "100元"
            doc.add_paragraph("結尾")
            doc.save(p)
            self.assertEqual(detect_file_type(p)[0], "docx")
            result = parse_attachment(p, "docx")
            self.assertEqual(result["parse_status"], "SUCCESS")
            self.assertLess(result["text"].index("開始"), result["text"].index("金額"))
            self.assertLess(result["text"].index("100元"), result["text"].index("結尾"))

    def test_full_download_opt_in_does_not_truncate(self):
        with tempfile.TemporaryDirectory() as root:
            client = HttpClient(delay=0)
            body = b"%PDF-1.7" + b"x" * 10000
            response = FakeResponse(body=body, headers={"Content-Type": "application/octet-stream"})
            target = Path(root) / "file.bin"
            with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=response):
                result = client.fetch("https://web.law.ntpc.gov.tw/Download.ashx?pfid=1", download_path=target)
            self.assertEqual(result["status"], "ok")
            self.assertEqual(target.read_bytes(), body)
            self.assertFalse(target.with_suffix(".bin.part").exists())
            client.close()

    def test_download_size_limit_keeps_partial(self):
        with tempfile.TemporaryDirectory() as root:
            client = HttpClient(delay=0)
            response = FakeResponse(body=b"%PDF-" + b"a" * 5000)
            target = Path(root) / "file.bin"
            with patch.object(client, "check_robots", return_value=True), patch.object(client.session, "request", return_value=response):
                result = client.fetch("https://web.law.ntpc.gov.tw/Download.ashx?pfid=1", download_path=target, max_download_bytes=1024)
            self.assertEqual(result["status"], "download_too_large")
            self.assertFalse(target.exists())
            self.assertTrue(target.with_suffix(".bin.part").exists())
            client.close()

    def test_blocked_source_does_not_request(self):
        with tempfile.TemporaryDirectory() as root:
            raw = RawStore(root)
            with patch.object(raw.client, "fetch") as fetch:
                with self.assertRaises(RawUnavailable):
                    raw.html({"source_url": "http://web.law.ntpc.gov.tw/a", "crawl_status": "robots_blocked"})
            fetch.assert_not_called()
            raw.close()

    def test_merged_docx_table_requires_review(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / "merged.docx"
            doc = WordDocument()
            table = doc.add_table(rows=2, cols=2)
            table.cell(0, 0).merge(table.cell(0, 1)).text = "裁罰表"
            table.cell(1, 0).text = "第一次"
            table.cell(1, 1).text = "五萬元"
            doc.save(p)
            result = parse_attachment(p, "docx")
            self.assertEqual(result["parse_status"], "TABLE_REVIEW_REQUIRED")
            self.assertIn("五萬元", result["text"])

    def test_raw_cache_reuse_and_hash_integrity(self):
        with tempfile.TemporaryDirectory() as root:
            raw = RawStore(root, offline=True)
            source = {"id": "s", "source_url": "https://web.law.ntpc.gov.tw/Download.ashx?pfid=1", "crawl_status": "success"}
            p = Path(root) / "pdf" / "s.pdf"
            p.write_bytes(b"%PDF-test")
            raw.record(source, p, "pdf", "test")
            with patch.object(raw.client, "fetch") as fetch:
                self.assertEqual(raw.attachment(source)["path"], p.as_posix())
                p.write_bytes(b"changed")
                with self.assertRaises(RawUnavailable):
                    raw.attachment(source)
            fetch.assert_not_called()
            raw.close()

    def test_one_corrupt_document_does_not_stop_next(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            bad, good = root / "bad.pdf", root / "good.pdf"
            bad.write_bytes(b"%PDF-corrupted")
            with pymupdf.open() as pdf:
                page = pdf.new_page()
                page.insert_text((50, 50), "A valid document after a broken document, with enough text.")
                pdf.save(good)
            sources = [{"id": name, "source_url": f"https://web.law.ntpc.gov.tw/Download.ashx?pfid={name}", "source_type": "direct_attachment", "crawl_status": "success", "title": name, "categories": ["測試"]} for name in ["bad", "good"]]
            results = [{"path": p.as_posix(), "source_id": name, "file_type": "pdf", "format_evidence": ["magic:%PDF-"]} for name, p in [("bad", bad), ("good", good)]]
            with patch.object(RawStore, "attachment", side_effect=results), patch("builtins.print"):
                docs, summary = run_documents(sources, offline=True, raw_dir=root / "raw", processed_dir=root / "processed")
            self.assertEqual([d["parse_status"] for d in docs], ["PARSE_FAILED", "SUCCESS"])
            self.assertIsNone(docs[0]["processed_file"])
            self.assertTrue(Path(docs[1]["processed_file"]).exists())


if __name__ == "__main__":
    unittest.main()
